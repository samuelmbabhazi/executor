/** Promise APIs are confined to this driver adapter; Effect owns browser and context scopes. */
import {
  chromium,
  webkit,
  type Browser as NativeBrowser,
  type BrowserType,
  type Page,
} from "playwright";
import {
  Cause,
  Clock,
  Config,
  Console,
  Context,
  Effect,
  Exit,
  FileSystem,
  Layer,
  Redacted,
  Result,
  Schedule,
} from "effect";
import { Target, driver, type DriverFailed } from "./platform.ts";
import { targetHosts } from "./role-hosts.ts";
import { splitRoutedReads } from "./read-batches.ts";
import { Evidence } from "./evidence.ts";
import type { Session } from "./api.ts";
import { RecordingFocus } from "./recording-focus.ts";
import { captureUIObservations } from "./ui-observation.ts";

const launchBrowser = (
  options: { readonly headless: boolean; readonly slowMo: number },
  engine: BrowserType = chromium,
) =>
  Effect.acquireRelease(
    driver("launch browser", () => engine.launch(options)),
    (browser) => driver("close browser", () => browser.close()).pipe(Effect.orDie),
  );

/**
 * Headless Chromium names itself "HeadlessChrome", which the dashboard server treats as a crawler
 * and answers only once the whole page has rendered. Cases present the desktop Chrome identity so
 * they receive the streamed page a person's browser receives.
 */
const visitorUserAgent = (browser: NativeBrowser) =>
  browser.browserType().name() === "chromium"
    ? {
        userAgent: `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${browser.version().split(".")[0]}.0.0.0 Safari/537.36`,
      }
    : {};

const captureBrowser = (engine: BrowserType) =>
  Effect.gen(function* () {
    const target = yield* Target;
    return yield* launchBrowser(
      {
        headless: target.headless ?? !target.metadata.interactive,
        slowMo: target.recordingPaceMs,
      },
      engine,
    );
  });

/** Suite-scoped Playwright process injected into browser and recording services. */
export class BrowserDriver extends Context.Service<BrowserDriver, NativeBrowser>()(
  "e2e/BrowserDriver",
) {
  /** Rendering is never paced, even when the source recording was captured slowly. */
  static readonly layer = Layer.effect(BrowserDriver, launchBrowser({ headless: true, slowMo: 0 }));
  /** Instrument individual actions, including several actions inside one use call. */
  static readonly captureLayer = Layer.effect(BrowserDriver, captureBrowser(chromium));
  /** Safari's engine, for behavior that differs from Chromium. */
  static readonly webkitCaptureLayer = Layer.effect(BrowserDriver, captureBrowser(webkit));
}
/** A case-scoped browser with captured steps and a single isolated context. */
export class Browser extends Context.Service<
  Browser,
  {
    readonly use: <A>(
      label: string,
      action: (page: Page) => Promise<A>,
    ) => Effect.Effect<A, DriverFailed>;
    readonly login: (session: Session) => Effect.Effect<void, DriverFailed>;
    readonly checkpoint: (name: string) => Effect.Effect<void, DriverFailed>;
    /** Discard network traces before OAuth; videos and screenshots still capture the UI. */
    readonly omitNetworkTrace: Effect.Effect<void, DriverFailed>;
  }
>()("e2e/Browser") {
  static readonly layer = Layer.effect(
    Browser,
    Effect.gen(function* () {
      const browser = yield* BrowserDriver,
        target = yield* Target,
        evidence = yield* Evidence,
        recording = yield* RecordingFocus;
      const clock = yield* Clock.Clock;
      const scope = yield* Effect.scope;
      const navigations: { at: string; url: string; elapsedMs: number; page: number }[] = [];
      const traceIds = new Set<string>();
      const failureReads: Promise<void>[] = [];
      const failedResources: {
        url: string;
        kind: string;
        status?: number;
        error?: string;
        site?: string;
        mode?: string;
        appCookie?: boolean;
        originMatches?: boolean;
      }[] = [];
      let page: Page | undefined;
      // Whether the current document has been seen responding to input; see `interactive`.
      let responsive = false;
      let tracing = true;
      const context = yield* driver("create browser context", () =>
        browser.newContext({
          baseURL: targetHosts(target).browser,
          viewport: { width: 1440, height: 960 },
          ...visitorUserAgent(browser),
          recordVideo: { dir: `${evidence.directory}/raw`, size: { width: 1440, height: 960 } },
        }),
      );
      yield* driver("route batched reads through test routes", () =>
        splitRoutedReads(context, targetHosts(target).browser),
      );
      // `E2E_COVERAGE=1` records the JavaScript coverage of every page Chromium opens, from its first
      // script, for `e2e/coverage.ts` to map to the dashboards' sources.
      const fs = yield* FileSystem.FileSystem;
      const coverage =
        (yield* Config.Boolean("E2E_COVERAGE").pipe(Config.withDefault(false))) &&
        target.scenarioId !== undefined &&
        browser.browserType().name() === "chromium"
          ? `${target.evidenceDirectory ?? target.directory}/coverage/${target.scenarioId}`
          : undefined;
      const profiling = new Map<Page, Promise<void>>();
      if (coverage !== undefined)
        context.on("page", (opened) =>
          profiling.set(
            opened,
            opened.coverage.startJSCoverage({ resetOnNavigation: false }).catch(() => {
              profiling.delete(opened);
            }),
          ),
        );
      const saveCoverage = Effect.gen(function* () {
        if (coverage === undefined) return;
        yield* fs.makeDirectory(`${coverage}/browser`, { recursive: true });
        if (!(yield* fs.exists(`${coverage}/scenario.json`)))
          yield* fs.writeFileString(
            `${coverage}/scenario.json`,
            JSON.stringify({ target: target.metadata.target, title: target.scenarioLabel }),
          );
        let index = 0;
        for (const [opened, started] of profiling) {
          if (opened.isClosed()) continue;
          const entries = yield* driver("read browser coverage", () =>
            started.then(() => opened.coverage.stopJSCoverage()),
          );
          yield* fs.writeFileString(
            `${coverage}/browser/browser-${index++}.json`,
            JSON.stringify(
              entries
                .filter(({ url }) => /^https?:/.test(url))
                .map(({ url, functions }) => ({ url, functions })),
            ),
          );
        }
      });
      // Register cleanup immediately, before trace/page setup can fail.
      yield* Effect.addFinalizer((exit) =>
        Effect.gen(function* () {
          if (page && Exit.isFailure(exit)) {
            const failedPage = page;
            if (target.metadata.interactive && !Cause.hasInterrupts(exit.cause)) {
              yield* evidence.intervention("Paused at failure");
              yield* driver("pause failed browser", () => failedPage.pause()).pipe(
                Effect.interruptible,
                Effect.ignore,
              );
            }
            const screenshot = yield* driver("failure screenshot", () =>
              failedPage.screenshot({ timeout: 5000 }),
            ).pipe(Effect.result);
            if (Result.isSuccess(screenshot))
              yield* evidence.attach("failure.png", "image/png", screenshot.success);
          }
          if (tracing) {
            yield* driver("save browser trace", () =>
              context.tracing.stop({ path: `${evidence.directory}/trace.zip` }),
            ).pipe(Effect.orDie);
            yield* evidence.artifact("Playwright trace", "application/zip", "trace.zip");
          }
          const video = page?.video();
          // Coverage is evidence about the suite, not the scenario; it never fails one.
          yield* saveCoverage.pipe(Effect.ignore);
          yield* driver("close browser context", () => context.close()).pipe(Effect.orDie);
          yield* driver("collect sanitized resource failures", () =>
            Promise.all(failureReads),
          ).pipe(Effect.orDie);
          if (video) {
            // A scenario can close its page before context cleanup. saveAs waits
            // for that page's encoder; path alone can still point at an empty file.
            yield* driver("save completed recording", () =>
              video.saveAs(`${evidence.directory}/raw.webm`),
            ).pipe(Effect.orDie);
            yield* evidence.artifact("Browser recording", "video/webm", "raw.webm");
          }
          yield* evidence.json("navigation.json", navigations);
          yield* evidence.json("failed-resources.json", failedResources);
          for (const id of traceIds) yield* evidence.browserTrace(id);
        }),
      );
      yield* driver("start browser trace", () =>
        context.tracing.start({ screenshots: true, snapshots: true, sources: true }),
      );
      const getPage = yield* Effect.cached(
        Effect.gen(function* () {
          const started = yield* Clock.currentTimeMillis;
          page = yield* driver("open browser page", () => context.newPage());
          const current = page;
          // Profile from the page's first script.
          yield* driver(
            "start browser coverage",
            () => profiling.get(current) ?? Promise.resolve(),
          );
          const capture = yield* captureUIObservations(current, evidence, scope, target);
          const focus = yield* recording.open({
            kind: "browser",
            title: "Browser",
            file: "recording.mp4",
            startedAtMs: started,
          });
          current.setDefaultTimeout(15000);
          current.setDefaultNavigationTimeout(30000);
          current.on("framenavigated", (frame) => {
            if (frame === current.mainFrame()) {
              responsive = false;
              const url = new URL(frame.url());
              const now = clock.currentTimeMillisUnsafe();
              navigations.push({
                at: new Date(now).toISOString(),
                url: `${url.origin}${url.pathname}`,
                elapsedMs: now - started,
                page: 0,
              });
            }
          });
          current.on("request", (request) => {
            const id = request.headers()["traceparent"]?.split("-")[1];
            if (id && /^[a-f0-9]{32}$/.test(id)) traceIds.add(id);
          });
          // Retain safe failure evidence even when OAuth requires discarding the network trace.
          current.on("response", (response) => {
            const kind = response.request().resourceType();
            const status = response.status();
            if (
              status < 400 &&
              !(kind === "script" && response.headers()["content-type"]?.includes("text/html"))
            )
              return;
            const url = new URL(response.url());
            failureReads.push(
              response
                .request()
                .allHeaders()
                .then((headers) => {
                  failedResources.push({
                    url: `${url.origin}${url.pathname}`,
                    kind,
                    status,
                    site: headers["sec-fetch-site"] ?? "absent",
                    mode: headers["sec-fetch-mode"] ?? "absent",
                    appCookie: headers.cookie?.includes("__Host-executor_app=") === true,
                    originMatches: headers.origin === undefined || headers.origin === url.origin,
                  });
                })
                .catch(() => {
                  failedResources.push({ url: `${url.origin}${url.pathname}`, kind, status });
                }),
            );
          });
          current.on("requestfailed", (request) => {
            const url = new URL(request.url());
            const reason = request.failure()?.errorText;
            failedResources.push({
              url: `${url.origin}${url.pathname}`,
              kind: request.resourceType(),
              error:
                reason !== undefined && /^net::ERR_[A-Z_]+$/.test(reason)
                  ? reason
                  : "NETWORK_ERROR",
            });
          });
          return { page: current, focus, capture };
        }),
      );
      // Dashboard documents arrive rendered but respond to input only once hydrated, as for
      // a person waiting for the page's scripts. Regions stream in after the page itself
      // hydrates; TanStack removes `$_TSR` once the router has hydrated and the whole document
      // has arrived. Other pages, such as sign-in providers, do not wait. A scenario that stops
      // a dashboard from starting continues after the wait expires; its own assertions decide
      // the outcome.
      // The check walks only comment nodes natively, so it stays cheap on a page with a very
      // large DOM. An evaluation that a navigation interrupts is repeated on the new document.
      // Once a document responds or the wait expires, later steps skip the check until the page
      // navigates again.
      const interactive = (page: Page) =>
        Effect.suspend(() =>
          responsive
            ? Effect.void
            : driver("page responds to input", () =>
                page.evaluate(() => {
                  const root = document.documentElement;
                  if (!root.hasAttribute("data-dashboard")) return true;
                  if (!root.hasAttribute("data-hydrated") || "$_TSR" in window) return false;
                  // Regions streamed into the page hydrate after the page itself. React marks
                  // each element it has hydrated; the first element of every completed region
                  // must carry that mark.
                  // A region that has arrived is not shown at once: React batches reveals and
                  // may hold one for several hundred milliseconds after the router hydrates.
                  // Until then the region is marked `$?` or `$~`, its fallback is on screen and
                  // its content waits in a hidden element that does not respond to input.
                  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_COMMENT);
                  for (let node = walker.nextNode(); node !== null; node = walker.nextNode()) {
                    if (!(node instanceof Comment)) continue;
                    if (node.data === "$?" || node.data === "$~") return false;
                    if (node.data !== "$") continue;
                    // The region ends at its closing marker; an empty region has no element.
                    let first = node.nextSibling;
                    while (
                      first !== null &&
                      !(first instanceof Element) &&
                      !(first instanceof Comment && first.data === "/$")
                    )
                      first = first.nextSibling;
                    if (
                      first instanceof Element &&
                      !Object.keys(first).some((key) => key.startsWith("__reactFiber$"))
                    )
                      return false;
                  }
                  return true;
                }),
              ).pipe(
                Effect.flatMap((ready) =>
                  ready
                    ? Effect.sync(() => {
                        responsive = true;
                      })
                    : Effect.fail("hydrating" as const),
                ),
                Effect.retry({ schedule: Schedule.spaced("50 millis") }),
                Effect.timeout("10 seconds"),
                Effect.ignore,
                // Wait once per document. A document that never responds is not waited on again
                // by later steps until the page navigates.
                Effect.ensuring(
                  Effect.sync(() => {
                    responsive = true;
                  }),
                ),
              ),
        );
      const use = <A>(label: string, action: (page: Page) => Promise<A>) =>
        evidence.step(
          label,
          Effect.flatMap(getPage, ({ page, focus, capture }) =>
            focus.use(
              label,
              driver(label, () => action(page)).pipe(
                Effect.tap(() => interactive(page)),
                Effect.tap(() => capture.settle),
              ),
            ),
          ),
        );
      return Browser.of({
        use,
        omitNetworkTrace: Effect.gen(function* () {
          if (tracing) {
            yield* driver("discard credential-bearing browser trace", () => context.tracing.stop());
            tracing = false;
          }
        }),
        login: (session) =>
          Effect.gen(function* () {
            const { focus } = yield* getPage;
            yield* focus.use(
              "Set browser actor",
              Effect.gen(function* () {
                yield* driver("clear browser cookies", () => context.clearCookies());
                const cookies = yield* session.cookies;
                yield* driver("set actor session", () =>
                  context.addCookies([...Redacted.value(cookies)]),
                );
              }),
            );
          }),
        checkpoint: (name) =>
          Effect.gen(function* () {
            const { page, focus } = yield* getPage;
            yield* focus.use(
              name,
              Effect.gen(function* () {
                const screenshot = yield* driver("capture checkpoint", () => page.screenshot());
                yield* evidence.attach(
                  `checkpoint-${navigations.length}-${name.replace(/[^a-z0-9]/gi, "-")}.png`,
                  "image/png",
                  screenshot,
                );
                if (target.metadata.interactive) {
                  yield* evidence.intervention(name);
                  yield* Console.log(
                    `Paused: ${name}. Use the browser, then Resume in Playwright Inspector.`,
                  );
                  yield* driver("manual takeover", () => page.pause());
                }
              }),
            );
          }),
      });
    }),
  );
}
