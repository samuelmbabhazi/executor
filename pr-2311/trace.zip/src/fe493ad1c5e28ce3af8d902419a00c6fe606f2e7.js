/**
 * Shared Node-compatible implementation of Effect's `FileSystem` service.
 *
 * This module adapts Node's `node:fs`, `node:os`, and `node:path` APIs into a
 * `FileSystem` layer for Effect programs running on Node-compatible runtimes.
 * Platform packages use it to provide file and directory I/O, permissions,
 * links, metadata, temporary files and directories, and file watching through
 * the shared `FileSystem` service.
 *
 * @since 4.0.0
 */
import * as BI from "effect/BigInt";
import * as ByteSize from "effect/ByteSize";
import * as Cause from "effect/Cause";
import * as Effect from "effect/Effect";
import { effectify } from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import { pipe } from "effect/Function";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Error from "effect/PlatformError";
import * as Queue from "effect/Queue";
import * as Stream from "effect/Stream";
import * as Crypto from "node:crypto";
import * as NFS from "node:fs";
import * as OS from "node:os";
import * as Path from "node:path";
import { handleErrnoException } from "./internal/utils.js";
const handleBadArgument = method => err => Error.badArgument({
  module: "FileSystem",
  method,
  description: err.message ?? String(err)
});
const bigintToNumber = (value, field) => {
  const number = Number(value);
  if (!Number.isSafeInteger(number)) {
    throw new RangeError(`${field} exceeds the safe integer range: ${value}`);
  }
  return number;
};
const bigintToNumberOption = value => Option.flatMap(Option.fromNullishOr(value), BI.toNumber);
// fs.write ignores bigint positions.
const positionToNumber = (position, method) => Effect.try({
  try: () => bigintToNumber(position, "position"),
  catch: handleBadArgument(method)
});
// == access
const access = /*#__PURE__*/(() => {
  const nodeAccess = /*#__PURE__*/effectify(NFS.access, /*#__PURE__*/handleErrnoException("FileSystem", "access"), /*#__PURE__*/handleBadArgument("access"));
  return (path, options) => {
    let mode = NFS.constants.F_OK;
    if (options?.readable) {
      mode |= NFS.constants.R_OK;
    }
    if (options?.writable) {
      mode |= NFS.constants.W_OK;
    }
    return nodeAccess(path, mode);
  };
})();
// == copy
const copy = /*#__PURE__*/(() => {
  const nodeCp = /*#__PURE__*/effectify(NFS.cp, /*#__PURE__*/handleErrnoException("FileSystem", "copy"), /*#__PURE__*/handleBadArgument("copy"));
  return (fromPath, toPath, options) => nodeCp(fromPath, toPath, {
    force: options?.overwrite ?? false,
    preserveTimestamps: options?.preserveTimestamps ?? false,
    recursive: true
  });
})();
// == copyFile
const copyFile = /*#__PURE__*/(() => {
  const nodeCopyFile = /*#__PURE__*/effectify(NFS.copyFile, /*#__PURE__*/handleErrnoException("FileSystem", "copyFile"), /*#__PURE__*/handleBadArgument("copyFile"));
  return (fromPath, toPath) => nodeCopyFile(fromPath, toPath);
})();
// == chmod
const chmod = /*#__PURE__*/(() => {
  const nodeChmod = /*#__PURE__*/effectify(NFS.chmod, /*#__PURE__*/handleErrnoException("FileSystem", "chmod"), /*#__PURE__*/handleBadArgument("chmod"));
  return (path, mode) => nodeChmod(path, mode);
})();
// == chown
const chown = /*#__PURE__*/(() => {
  const nodeChown = /*#__PURE__*/effectify(NFS.chown, /*#__PURE__*/handleErrnoException("FileSystem", "chown"), /*#__PURE__*/handleBadArgument("chown"));
  return (path, uid, gid) => nodeChown(path, uid, gid);
})();
// == glob
const glob = /*#__PURE__*/(() => {
  const nodeGlob = /*#__PURE__*/effectify(NFS.glob, /*#__PURE__*/handleErrnoException("FileSystem", "glob"), /*#__PURE__*/handleBadArgument("glob"));
  return (pattern, options) => nodeGlob(pattern, {
    cwd: options?.root,
    exclude: options?.exclude
  });
})();
// == link
const link = /*#__PURE__*/(() => {
  const nodeLink = /*#__PURE__*/effectify(NFS.link, /*#__PURE__*/handleErrnoException("FileSystem", "link"), /*#__PURE__*/handleBadArgument("link"));
  return (existingPath, newPath) => nodeLink(existingPath, newPath);
})();
// == makeDirectory
const makeDirectory = /*#__PURE__*/(() => {
  const nodeMkdir = /*#__PURE__*/effectify(NFS.mkdir, /*#__PURE__*/handleErrnoException("FileSystem", "makeDirectory"), /*#__PURE__*/handleBadArgument("makeDirectory"));
  return (path, options) => nodeMkdir(path, {
    recursive: options?.recursive ?? false,
    mode: options?.mode
  });
})();
// == makeTempDirectory
const makeTempDirectoryFactory = method => {
  const nodeMkdtemp = effectify(NFS.mkdtemp, handleErrnoException("FileSystem", method), handleBadArgument(method));
  return options => Effect.suspend(() => {
    const prefix = options?.prefix ?? "";
    const directory = typeof options?.directory === "string" ? Path.join(options.directory, ".") : OS.tmpdir();
    return nodeMkdtemp(prefix ? Path.join(directory, prefix) : directory + "/");
  });
};
const makeTempDirectory = /*#__PURE__*/makeTempDirectoryFactory("makeTempDirectory");
// == remove
const removeFactory = method => {
  const nodeRm = effectify(NFS.rm, handleErrnoException("FileSystem", method), handleBadArgument(method));
  return (path, options) => nodeRm(path, {
    recursive: options?.recursive ?? false,
    force: options?.force ?? false
  });
};
const remove = /*#__PURE__*/removeFactory("remove");
// == makeTempDirectoryScoped
const makeTempDirectoryScoped = /*#__PURE__*/(() => {
  const makeDirectory = /*#__PURE__*/makeTempDirectoryFactory("makeTempDirectoryScoped");
  const removeDirectory = /*#__PURE__*/removeFactory("makeTempDirectoryScoped");
  return options => Effect.acquireRelease(makeDirectory(options), directory => Effect.orDie(removeDirectory(directory, {
    recursive: true
  })));
})();
// == open
const openFactory = method => {
  const nodeOpen = effectify(NFS.open, handleErrnoException("FileSystem", method), handleBadArgument(method));
  const nodeClose = effectify(NFS.close, handleErrnoException("FileSystem", method), handleBadArgument(method));
  return (path, options) => pipe(Effect.acquireRelease(nodeOpen(path, options?.flag ?? "r", options?.mode), fd => Effect.orDie(nodeClose(fd))), Effect.map(fd => makeFile(fd, options?.flag?.startsWith("a") ?? false)));
};
const open = /*#__PURE__*/openFactory("open");
const makeFile = /*#__PURE__*/(() => {
  const nodeReadFactory = method => effectify(NFS.read, handleErrnoException("FileSystem", method), handleBadArgument(method));
  const nodeRead = /*#__PURE__*/nodeReadFactory("read");
  const nodeReadAlloc = /*#__PURE__*/nodeReadFactory("readAlloc");
  const nodeStat = /*#__PURE__*/effectify(NFS.fstat, /*#__PURE__*/handleErrnoException("FileSystem", "stat"), /*#__PURE__*/handleBadArgument("stat"));
  const nodeTruncate = /*#__PURE__*/effectify(NFS.ftruncate, /*#__PURE__*/handleErrnoException("FileSystem", "truncate"), /*#__PURE__*/handleBadArgument("truncate"));
  const nodeSync = /*#__PURE__*/effectify(NFS.fsync, /*#__PURE__*/handleErrnoException("FileSystem", "sync"), /*#__PURE__*/handleBadArgument("sync"));
  const nodeWriteFactory = method => effectify(NFS.write, handleErrnoException("FileSystem", method), handleBadArgument(method));
  const nodeWrite = /*#__PURE__*/nodeWriteFactory("write");
  const nodeWriteAll = /*#__PURE__*/nodeWriteFactory("writeAll");
  class FileImpl {
    [FileSystem.FileTypeId];
    fd;
    append;
    position = /*#__PURE__*/BigInt(0);
    constructor(fd, append) {
      this[FileSystem.FileTypeId] = FileSystem.FileTypeId;
      this.fd = fd;
      this.append = append;
    }
    get stat() {
      return Effect.flatMap(nodeStat(this.fd, {
        bigint: true
      }), makeFileInfo);
    }
    get sync() {
      return nodeSync(this.fd);
    }
    seek(offset, from) {
      return Effect.suspend(() => {
        const position = from === "start" ? offset : this.position + offset;
        if (position < BigInt(0)) {
          return Effect.fail(Error.badArgument({
            module: "FileSystem",
            method: "seek",
            description: "Cannot seek before the start of the file"
          }));
        }
        this.position = position;
        return Effect.succeed(position);
      });
    }
    read(buffer) {
      return Effect.suspend(() => {
        const position = this.position;
        return Effect.map(nodeRead(this.fd, {
          buffer,
          position
        }), bytesRead => {
          this.position = position + BigInt(bytesRead);
          return bytesRead;
        });
      });
    }
    readAlloc(size) {
      return Effect.suspend(() => {
        try {
          if (!Number.isInteger(size) || size < 0) {
            throw new RangeError("size must be a non-negative integer");
          }
          const buffer = Buffer.allocUnsafeSlow(size);
          const position = this.position;
          return Effect.map(nodeReadAlloc(this.fd, {
            buffer,
            position
          }), bytesRead => {
            if (bytesRead === 0) {
              return Option.none();
            }
            this.position = position + BigInt(bytesRead);
            if (bytesRead === size) {
              return Option.some(buffer);
            }
            const dst = Buffer.allocUnsafeSlow(bytesRead);
            buffer.copy(dst, 0, 0, bytesRead);
            return Option.some(dst);
          });
        } catch (cause) {
          return Effect.fail(handleBadArgument("readAlloc")(cause));
        }
      });
    }
    truncate(length) {
      return Effect.map(nodeTruncate(this.fd, length || undefined), () => {
        if (!this.append) {
          const len = BigInt(length ?? 0);
          if (this.position > len) {
            this.position = len;
          }
        }
      });
    }
    write(buffer) {
      return Effect.suspend(() => {
        const position = this.position;
        return Effect.flatMap(this.append ? Effect.succeed(undefined) : positionToNumber(position, "write"), nodePosition => Effect.map(nodeWrite(this.fd, buffer, undefined, undefined, nodePosition), bytesWritten => {
          if (!this.append) {
            this.position = position + BigInt(bytesWritten);
          }
          return bytesWritten;
        }));
      });
    }
    writeAllChunk(buffer) {
      return Effect.suspend(() => {
        const position = this.position;
        return Effect.flatMap(this.append ? Effect.succeed(undefined) : positionToNumber(position, "writeAll"), nodePosition => Effect.flatMap(nodeWriteAll(this.fd, buffer, undefined, undefined, nodePosition), bytesWritten => {
          if (bytesWritten === 0) {
            return Effect.fail(Error.systemError({
              module: "FileSystem",
              method: "writeAll",
              _tag: "WriteZero",
              pathOrDescriptor: this.fd,
              description: "write returned 0 bytes written"
            }));
          }
          if (!this.append) {
            this.position = position + BigInt(bytesWritten);
          }
          return bytesWritten < buffer.length ? this.writeAllChunk(buffer.subarray(bytesWritten)) : Effect.void;
        }));
      });
    }
    writeAll(buffer) {
      return buffer.length === 0 ? Effect.void : this.writeAllChunk(buffer);
    }
  }
  return (fd, append) => new FileImpl(fd, append);
})();
// == makeTempFile
const makeTempFileFactory = method => {
  const makeDirectory = makeTempDirectoryFactory(method);
  return Effect.fnUntraced(function* (options) {
    const directory = yield* makeDirectory(options);
    const random = Crypto.randomBytes(6).toString("hex");
    const name = Path.join(directory, options?.suffix ? `${random}${options.suffix}` : random);
    yield* writeFile(name, new Uint8Array(0));
    return name;
  });
};
const makeTempFile = /*#__PURE__*/makeTempFileFactory("makeTempFile");
// == makeTempFileScoped
const makeTempFileScoped = /*#__PURE__*/(() => {
  const makeFile = /*#__PURE__*/makeTempFileFactory("makeTempFileScoped");
  const removeDirectory = /*#__PURE__*/removeFactory("makeTempFileScoped");
  return options => Effect.acquireRelease(makeFile(options), file => Effect.orDie(removeDirectory(Path.dirname(file), {
    recursive: true
  })));
})();
// == readDirectory
const readDirectory = (path, options) => Effect.tryPromise({
  try: () => NFS.promises.readdir(path, options),
  catch: err => handleErrnoException("FileSystem", "readDirectory")(err, [path])
});
// == readFile
const readFile = path => Effect.callback((resume, signal) => {
  try {
    NFS.readFile(path, {
      signal
    }, (err, data) => {
      if (err) {
        resume(Effect.fail(handleErrnoException("FileSystem", "readFile")(err, [path])));
      } else {
        resume(Effect.succeed(data));
      }
    });
  } catch (err) {
    resume(Effect.fail(handleBadArgument("readFile")(err)));
  }
});
// == readLink
const readLink = /*#__PURE__*/(() => {
  const nodeReadLink = /*#__PURE__*/effectify(NFS.readlink, /*#__PURE__*/handleErrnoException("FileSystem", "readLink"), /*#__PURE__*/handleBadArgument("readLink"));
  return path => nodeReadLink(path);
})();
// == realPath
const realPath = /*#__PURE__*/(() => {
  const nodeRealPath = /*#__PURE__*/effectify(NFS.realpath, /*#__PURE__*/handleErrnoException("FileSystem", "realPath"), /*#__PURE__*/handleBadArgument("realPath"));
  return path => nodeRealPath(path);
})();
// == rename
const rename = /*#__PURE__*/(() => {
  const nodeRename = /*#__PURE__*/effectify(NFS.rename, /*#__PURE__*/handleErrnoException("FileSystem", "rename"), /*#__PURE__*/handleBadArgument("rename"));
  return (oldPath, newPath) => nodeRename(oldPath, newPath);
})();
// == stat
const makeFileInfo = stat => Effect.try({
  try: () => ({
    type: stat.isFile() ? "File" : stat.isDirectory() ? "Directory" : stat.isSymbolicLink() ? "SymbolicLink" : stat.isBlockDevice() ? "BlockDevice" : stat.isCharacterDevice() ? "CharacterDevice" : stat.isFIFO() ? "FIFO" : stat.isSocket() ? "Socket" : "Unknown",
    mtime: Option.fromNullishOr(stat.mtime),
    atime: Option.fromNullishOr(stat.atime),
    birthtime: Option.fromNullishOr(stat.birthtime),
    dev: bigintToNumber(stat.dev, "dev"),
    rdev: bigintToNumberOption(stat.rdev),
    ino: bigintToNumberOption(stat.ino),
    mode: bigintToNumber(stat.mode, "mode"),
    nlink: bigintToNumberOption(stat.nlink),
    uid: bigintToNumberOption(stat.uid),
    gid: bigintToNumberOption(stat.gid),
    size: ByteSize.bytes(stat.size),
    blksize: stat.blksize !== undefined ? Option.some(ByteSize.bytes(stat.blksize)) : Option.none(),
    blocks: bigintToNumberOption(stat.blocks)
  }),
  catch: handleBadArgument("stat")
});
const stat = /*#__PURE__*/(() => {
  const nodeStat = /*#__PURE__*/effectify(NFS.stat, /*#__PURE__*/handleErrnoException("FileSystem", "stat"), /*#__PURE__*/handleBadArgument("stat"));
  return path => Effect.flatMap(nodeStat(path, {
    bigint: true
  }), makeFileInfo);
})();
// == symlink
const symlink = /*#__PURE__*/(() => {
  const nodeSymlink = /*#__PURE__*/effectify(NFS.symlink, /*#__PURE__*/handleErrnoException("FileSystem", "symlink"), /*#__PURE__*/handleBadArgument("symlink"));
  return (target, path) => nodeSymlink(target, path);
})();
// == truncate
const truncate = /*#__PURE__*/(() => {
  const nodeTruncate = /*#__PURE__*/effectify(NFS.truncate, /*#__PURE__*/handleErrnoException("FileSystem", "truncate"), /*#__PURE__*/handleBadArgument("truncate"));
  return (path, length) => nodeTruncate(path, length);
})();
// == utimes
const utimes = /*#__PURE__*/(() => {
  const nodeUtimes = /*#__PURE__*/effectify(NFS.utimes, /*#__PURE__*/handleErrnoException("FileSystem", "utime"), /*#__PURE__*/handleBadArgument("utime"));
  return (path, atime, mtime) => nodeUtimes(path, atime, mtime);
})();
// == watch
const watchNode = (path, info, options) => Stream.callback(queue => Effect.acquireRelease(Effect.sync(() => {
  const directory = info.type === "Directory" ? path : Path.dirname(path);
  const watcher = NFS.watch(path, {
    recursive: options?.recursive ?? false
  }, (event, path) => {
    if (!path) return;
    switch (event) {
      case "rename":
        {
          Effect.runFork(Effect.matchEffect(stat(Path.resolve(directory, path)), {
            onSuccess: _ => Queue.offer(queue, {
              _tag: "Create",
              path
            }),
            onFailure: _ => Queue.offer(queue, {
              _tag: "Remove",
              path
            })
          }));
          return;
        }
      case "change":
        {
          Queue.offerUnsafe(queue, {
            _tag: "Update",
            path
          });
          return;
        }
    }
  });
  watcher.on("error", error => {
    Queue.failCauseUnsafe(queue, Cause.fail(Error.systemError({
      module: "FileSystem",
      _tag: "Unknown",
      method: "watch",
      pathOrDescriptor: path,
      cause: error
    })));
  });
  watcher.on("close", () => {
    Queue.endUnsafe(queue);
  });
  return watcher;
}), watcher => Effect.sync(() => watcher.close())));
const watch = (backend, path, options) => stat(path).pipe(Effect.map(stat => backend.pipe(Option.flatMap(_ => _.register(path, stat, options)), Option.getOrElse(() => watchNode(path, stat, options)))), Stream.unwrap);
// == writeFile
const writeFile = (path, data, options) => Effect.callback((resume, signal) => {
  try {
    NFS.writeFile(path, data, {
      signal,
      flag: options?.flag,
      mode: options?.mode
    }, err => {
      if (err) {
        resume(Effect.fail(handleErrnoException("FileSystem", "writeFile")(err, [path])));
      } else {
        resume(Effect.void);
      }
    });
  } catch (err) {
    resume(Effect.fail(handleBadArgument("writeFile")(err)));
  }
});
const makeFileSystem = /*#__PURE__*/Effect.map(/*#__PURE__*/Effect.serviceOption(FileSystem.WatchBackend), backend => FileSystem.make({
  access,
  chmod,
  chown,
  copy,
  copyFile,
  glob,
  link,
  makeDirectory,
  makeTempDirectory,
  makeTempDirectoryScoped,
  makeTempFile,
  makeTempFileScoped,
  open,
  readDirectory,
  readFile,
  readLink,
  realPath,
  remove,
  rename,
  stat,
  symlink,
  truncate,
  utimes,
  watch(path, options) {
    return watch(backend, path, options);
  },
  writeFile
}));
/**
 * Provides the `FileSystem` service backed by Node filesystem APIs, including
 * file operations, directory operations, links, metadata, and file watching.
 *
 * @category layers
 * @since 4.0.0
 */
export const layer = /*#__PURE__*/Layer.effect(FileSystem.FileSystem)(makeFileSystem);
//# sourceMappingURL=NodeFileSystem.js.map