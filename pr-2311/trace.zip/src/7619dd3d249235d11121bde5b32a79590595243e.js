import * as Arr from "../Array.js";
import * as Context from "../Context.js";
import * as Duration from "../Duration.js";
import * as Equal from "../Equal.js";
import * as Filter from "../Filter.js";
import { formatJson } from "../Formatter.js";
import { constant, constFalse, constTrue, constUndefined, constVoid, dual, identity } from "../Function.js";
import * as Hash from "../Hash.js";
import { toJson, toStringUnknown } from "../Inspectable.js";
import * as Iterable from "../Iterable.js";
import * as Option from "../Option.js";
import * as Order from "../Order.js";
import { pipeArguments } from "../Pipeable.js";
import { hasProperty, isIterable, isString, isTagged } from "../Predicate.js";
import { currentFiberTypeId, redact } from "../Redactable.js";
import * as Result from "../Result.js";
import * as Scheduler from "../Scheduler.js";
import * as Tracer from "../Tracer.js";
import { internalCall } from "../Utils.js";
import { args, causeAnnotate, causeCombine, causeEmpty, causeFromReasons, CauseImpl, constEmptyAnnotations, contA, contAll, contE, evaluate, exitDie, exitFail, exitFailCause, exitSucceed, ExitTypeId, Fail, InterruptorStackTrace, isCause, isDieReason, isEffect, isFailReason, isInterruptReason, isNoSuchElementError, makePrimitive, makePrimitiveProto, NoSuchElementError, ReasonBase, StackTraceKey as CauseStackTrace, TaggedError, withFiber, Yield } from "./core.js";
import * as doNotation from "./doNotation.js";
import * as InternalMetric from "./metric.js";
import * as InternalRecord from "./record.js";
import { CurrentErrorReporters, CurrentLogAnnotations, CurrentLogLevel, CurrentLogSpans, CurrentStackFrame, MinimumLogLevel, TracerEnabled, TracerSpanAnnotations, TracerSpanLinks, TracerTimingEnabled } from "./references.js";
import { getStackTraceLimit, setStackTraceLimit } from "./stackTraceLimit.js";
import { addSpanStackTrace, makeStackCleaner } from "./tracer.js";
// ----------------------------------------------------------------------------
// Cause
// ----------------------------------------------------------------------------
/** @internal */
export class Interrupt extends ReasonBase {
  constructor(fiberId, annotations = constEmptyAnnotations) {
    super("Interrupt", annotations, "Interrupted");
    this.fiberId = fiberId;
  }
  toString() {
    return `Interrupt(${this.fiberId})`;
  }
  toJSON() {
    return {
      _tag: "Interrupt",
      fiberId: this.fiberId
    };
  }
  [Equal.symbol](that) {
    return isInterruptReason(that) && this.fiberId === that.fiberId && this.annotations === that.annotations;
  }
  [Hash.symbol]() {
    return Hash.combine(Hash.string(`${this._tag}:${this.fiberId}`))(Hash.random(this.annotations));
  }
}
/** @internal */
export const makeInterruptReason = fiberId => new Interrupt(fiberId);
/** @internal */
export const causeInterrupt = fiberId => new CauseImpl([new Interrupt(fiberId)]);
/** @internal */
export const hasFails = self => self.reasons.some(isFailReason);
/** @internal */
export const findFail = self => {
  const reason = self.reasons.find(isFailReason);
  return reason ? Result.succeed(reason) : Result.fail(self);
};
/** @internal */
export const findError = self => {
  for (let i = 0; i < self.reasons.length; i++) {
    const reason = self.reasons[i];
    if (reason._tag === "Fail") {
      return Result.succeed(reason.error);
    }
  }
  return Result.fail(self);
};
/** @internal */
export const findErrorOption = /*#__PURE__*/Filter.toOption(findError);
/** @internal */
export const hasDies = self => self.reasons.some(isDieReason);
/** @internal */
export const findDie = self => {
  const reason = self.reasons.find(isDieReason);
  return reason ? Result.succeed(reason) : Result.fail(self);
};
/** @internal */
export const findDefect = self => {
  const reason = self.reasons.find(isDieReason);
  return reason ? Result.succeed(reason.defect) : Result.fail(self);
};
/** @internal */
export const hasInterrupts = self => self.reasons.some(isInterruptReason);
/** @internal */
export const findInterrupt = self => {
  const reason = self.reasons.find(isInterruptReason);
  return reason ? Result.succeed(reason) : Result.fail(self);
};
/** @internal */
export const causeFilterInterruptors = self => {
  let interruptors;
  for (let i = 0; i < self.reasons.length; i++) {
    const f = self.reasons[i];
    if (f._tag !== "Interrupt") continue;
    interruptors ??= new Set();
    if (f.fiberId !== undefined) {
      interruptors.add(f.fiberId);
    }
  }
  return interruptors ? Result.succeed(interruptors) : Result.fail(self);
};
/** @internal */
export const causeInterruptors = self => {
  const result = causeFilterInterruptors(self);
  return Result.isFailure(result) ? emptySet : result.success;
};
const emptySet = /*#__PURE__*/new Set();
/** @internal */
export const hasInterruptsOnly = self => self.reasons.length > 0 && self.reasons.every(isInterruptReason);
/** @internal */
export const reasonAnnotations = self => Context.makeUnsafe(self.annotations);
/** @internal */
export const causeAnnotations = self => {
  const map = new Map();
  for (const f of self.reasons) {
    if (f.annotations.size > 0) {
      for (const [key, value] of f.annotations) {
        map.set(key, value);
      }
    }
  }
  return Context.makeUnsafe(map);
};
/** @internal */
export const causeMap = /*#__PURE__*/dual(2, (self, f) => {
  let hasFail = false;
  const failures = self.reasons.map(failure => {
    if (isFailReason(failure)) {
      hasFail = true;
      return new Fail(f(failure.error), failure.annotations);
    }
    return failure;
  });
  return hasFail ? causeFromReasons(failures) : self;
});
/** @internal */
export const causeSquash = self => {
  let die;
  for (const reason of self.reasons) {
    if (reason._tag === "Fail") return reason.error;
    if (reason._tag === "Die") die ??= reason;
  }
  if (die !== undefined) return die.defect;
  if (self.reasons.length > 0) return new globalThis.Error("All fibers interrupted without error");
  return new globalThis.Error("Empty cause");
};
/** @internal */
export const causePrettyErrors = (self, options) => {
  const errors = [];
  const interrupts = [];
  if (self.reasons.length === 0) return errors;
  const prevStackLimit = getStackTraceLimit();
  if (prevStackLimit !== 0) setStackTraceLimit(1);
  try {
    for (const failure of self.reasons) {
      if (failure._tag === "Interrupt") {
        interrupts.push(failure);
        continue;
      }
      errors.push(causePrettyError(failure._tag === "Die" ? failure.defect : failure.error, failure.annotations, options));
    }
    if (errors.length === 0) {
      const cause = new Error("The fiber was interrupted by:");
      cause.name = "InterruptCause";
      cause.stack = interruptCauseStack(cause, interrupts);
      const error = new globalThis.Error("All fibers interrupted without error", {
        cause
      });
      error.name = "InterruptError";
      error.stack = `${error.name}: ${error.message}`;
      errors.push(causePrettyError(error, interrupts[0].annotations, options));
    }
  } finally {
    if (prevStackLimit !== 0) setStackTraceLimit(prevStackLimit);
  }
  return errors;
};
/** @internal */
export const causePrettyError = (original, annotations, options) => {
  const kind = typeof original;
  let error;
  if (original && kind === "object") {
    error = new globalThis.Error(causePrettyMessage(original), {
      cause: original.cause ? causePrettyError(original.cause) : undefined
    });
    if (typeof original.name === "string") {
      error.name = original.name;
    }
    if (typeof original.stack === "string") {
      error.stack = cleanErrorStack(original.stack, error, annotations);
    } else {
      const stack = `${error.name}: ${error.message}`;
      error.stack = annotations ? addStackAnnotations(stack, annotations) : stack;
    }
    if (options?.includeCauseInStack) {
      error.stack = renderPrettyError(error);
    }
    for (const key of Object.keys(original)) {
      if (!(key in error)) {
        ;
        error[key] = original[key];
      }
    }
  } else {
    error = new globalThis.Error(!original ? `Unknown error: ${original}` : kind === "string" ? original : formatJson(original));
  }
  return error;
};
const causePrettyMessage = u => {
  if (typeof u.message === "string") {
    return u.message;
  } else if (typeof u.toString === "function" && u.toString !== Object.prototype.toString && u.toString !== Array.prototype.toString) {
    try {
      return u.toString();
    } catch {
      // something's off, rollback to json
    }
  }
  return formatJson(u);
};
const locationRegExp = /\((.*)\)/g;
const cleanErrorStack = (stack, error, annotations) => {
  const message = `${error.name}: ${error.message}`;
  const lines = (stack.startsWith(message) ? stack.slice(message.length) : stack).split("\n");
  const out = [message];
  for (let i = 1; i < lines.length; i++) {
    if (/Generator\.next|~effect\/(?:Effect|Utils)/.test(lines[i])) {
      break;
    }
    out.push(lines[i]);
  }
  return annotations ? addStackAnnotations(out.join("\n"), annotations) : out.join("\n");
};
const addStackAnnotations = (stack, annotations) => {
  const frame = annotations?.get(CauseStackTrace.key);
  if (frame) {
    stack = `${stack}\n${currentStackTrace(frame)}`;
  }
  return stack;
};
const interruptCauseStack = (error, interrupts) => {
  const out = [`${error.name}: ${error.message}`];
  for (const current of interrupts) {
    const fiberId = current.fiberId !== undefined ? `#${current.fiberId}` : "unknown";
    const frame = current.annotations.get(InterruptorStackTrace.key);
    out.push(`    at fiber (${fiberId})`);
    if (frame) out.push(currentStackTrace(frame));
  }
  return out.join("\n");
};
const currentStackTrace = frame => {
  const out = [];
  let current = frame;
  let i = 0;
  while (current && i < 10) {
    const stack = current.stack();
    if (stack) {
      const locationMatchAll = stack.matchAll(locationRegExp);
      let match = false;
      for (const [, location] of locationMatchAll) {
        match = true;
        out.push(`    at ${current.name} (${location})`);
      }
      if (!match) {
        out.push(`    at ${current.name} (${stack.replace(/^at /, "")})`);
      }
    } else {
      out.push(`    at ${current.name}`);
    }
    current = current.parent;
    i++;
  }
  return out.join("\n");
};
/** @internal */
export const causePretty = cause => causePrettyErrors(cause).map(renderPrettyError).join("\n");
const renderPrettyError = e => e.cause ? `${e.stack} {\n${renderErrorCause(e.cause, "  ")}\n}` : e.stack;
const renderErrorCause = (cause, prefix) => {
  const lines = cause.stack.split("\n");
  let stack = `${prefix}[cause]: ${lines[0]}`;
  for (let i = 1, len = lines.length; i < len; i++) {
    stack += `\n${prefix}${lines[i]}`;
  }
  if (cause.cause) {
    stack += ` {\n${renderErrorCause(cause.cause, `${prefix}  `)}\n${prefix}}`;
  }
  return stack;
};
// ----------------------------------------------------------------------------
// Fiber
// ----------------------------------------------------------------------------
/** @internal */
export const FiberTypeId = "~effect/Fiber";
const fiberVariance = {
  _A: identity,
  _E: identity
};
const fiberIdStore = {
  id: 0
};
const AsyncResource = /*#__PURE__*/(() => {
  try {
    return globalThis.process?.getBuiltinModule?.("node:async_hooks")?.AsyncResource;
  } catch {
    return undefined;
  }
})();
const captureAsyncContext = () => AsyncResource === undefined ? undefined : new AsyncResource("effect/Fiber");
/** @internal */
export const getCurrentFiber = () => globalThis[currentFiberTypeId];
/** @internal */
export class FiberImpl {
  constructor(context, interruptible = true) {
    this.setContext(context);
    this.id = ++fiberIdStore.id;
    this.currentOpCount = 0;
    this.interruptible = interruptible;
    this._stack = [];
    this._observers = undefined;
    this._exit = undefined;
    this._children = undefined;
    this._interruptedCause = undefined;
    this._yielded = undefined;
    this._running = false;
    this._deferredInterrupt = false;
    this._parent = undefined;
    this._asyncContext = undefined;
    this.cache.runtimeMetrics?.recordFiberStart(this.context);
  }
  get [FiberTypeId]() {
    return fiberVariance;
  }
  get currentDispatcher() {
    return this._dispatcher ??= this.cache.scheduler.makeDispatcher();
  }
  getRef(ref) {
    return Context.get(this.context, ref);
  }
  addObserver(cb) {
    if (this._exit) {
      cb(this._exit);
      return constVoid;
    }
    if (this._observers === undefined) {
      this._observers = [cb];
    } else {
      this._observers.push(cb);
    }
    return () => this.removeObserver(cb);
  }
  removeObserver(cb) {
    if (this._exit || this._observers === undefined) return;
    const index = this._observers.indexOf(cb);
    if (index >= 0) {
      this._observers.splice(index, 1);
    }
  }
  interruptUnsafe(fiberId, annotations) {
    if (this._exit) {
      return;
    }
    let cause = causeInterrupt(fiberId);
    if (this.cache.stackFrame) {
      cause = causeAnnotate(cause, Context.make(CauseStackTrace, this.cache.stackFrame));
    }
    if (annotations) {
      cause = causeAnnotate(cause, annotations);
    }
    this._interruptedCause = this._interruptedCause ? causeCombine(this._interruptedCause, cause) : cause;
    if (this.interruptible) {
      if (this._running) {
        this._deferredInterrupt = true;
      } else {
        this.evaluate(failCause(this._interruptedCause));
      }
    }
  }
  pollUnsafe() {
    return this._exit;
  }
  evaluate(effect) {
    if (this._exit) {
      return;
    } else if (this._asyncContext !== undefined) {
      const asyncContext = this._asyncContext;
      this._asyncContext = undefined;
      return asyncContext.runInAsyncScope(this.evaluate, this, effect);
    } else if (this._yielded !== undefined) {
      const yielded = this._yielded;
      this._yielded = undefined;
      yielded();
    }
    const exit = this.runLoop(effect);
    if (exit === Yield) {
      this._asyncContext = captureAsyncContext();
      return;
    }
    // the interruptChildren middleware is added in Effect.forkChild, so it can be
    // tree-shaken if not used
    const interruptChildren = fiberMiddleware.interruptChildren && fiberMiddleware.interruptChildren(this);
    if (interruptChildren !== undefined) {
      return this.evaluate(flatMap(interruptChildren, () => exit));
    }
    this._exit = exit;
    this.cache.runtimeMetrics?.recordFiberEnd(this.context, this._exit);
    if (this._parent) {
      this._parent._children?.delete(this);
      this._parent = undefined;
    }
    if (this._observers !== undefined) {
      const observers = this._observers;
      this._observers = undefined;
      for (let i = 0; i < observers.length; i++) {
        observers[i](exit);
      }
    }
    this._stack.length = 0;
    this._children = undefined;
    this.context = Context.empty();
  }
  runLoop(effect) {
    const prevFiber = globalThis[currentFiberTypeId];
    globalThis[currentFiberTypeId] = this;
    const prevRunning = this._running;
    this._running = true;
    let yielding = false;
    let current = effect;
    this.currentOpCount = 0;
    try {
      while (true) {
        if (this._deferredInterrupt) {
          this._deferredInterrupt = false;
          current = failCause(this._interruptedCause);
        }
        this.currentOpCount++;
        // Refresh the cache because a primitive can replace the fiber context.
        const cache = this.cache;
        if (!yielding && !cache.preventYield && cache.scheduler.shouldYield(this)) {
          yielding = true;
          const prev = current;
          current = flatMap(yieldNow, () => prev);
        }
        current = cache.tracerContext ? cache.tracerContext(current, this) : current[evaluate](this);
        if (current === Yield) {
          const yielded = this._yielded;
          if (ExitTypeId in yielded) {
            this._deferredInterrupt = false;
            this._yielded = undefined;
            return yielded;
          } else if (this._deferredInterrupt) {
            this._yielded = undefined;
            yielded();
            continue;
          }
          return Yield;
        }
      }
    } catch (error) {
      if (!hasProperty(current, evaluate)) {
        return exitDie(`Fiber.runLoop: Not a valid effect: ${String(current)}`);
      }
      return this.runLoop(exitDie(error));
    } finally {
      this._running = prevRunning;
      globalThis[currentFiberTypeId] = prevFiber;
    }
  }
  getCont(symbol) {
    if (this._deferredInterrupt) {
      this._deferredInterrupt = false;
      return deferredInterruptCont;
    }
    while (true) {
      const op = this._stack.pop();
      if (!op) return undefined;
      const all = op[contAll];
      if (all !== undefined) {
        const cont = all.call(op, this);
        if (cont) {
          ;
          cont[symbol] = cont;
          return cont;
        }
      }
      if (op[symbol]) return op;
    }
  }
  // Passes a success value straight to the next continuation instead of
  // returning an Exit for the run loop to unwrap. Each call counts as an
  // operation, and every `maxInlineSteps`th call returns an Exit instead, so
  // continuations calling continuations never nest deeper than that.
  succeedWith(value) {
    if ((++this.currentOpCount & maxInlineSteps - 1) === 0) {
      return exitSucceed(value);
    }
    const cont = this.getCont(contA);
    return cont ? cont[contA](value, this) : this.yieldWith(exitSucceed(value));
  }
  yieldWith(value) {
    this._yielded = value;
    return Yield;
  }
  children() {
    return this._children ??= new Set();
  }
  pipe() {
    return pipeArguments(this, arguments);
  }
  setContext(context) {
    const previous = this.context;
    this.context = context;
    // Every key cached below opts in to Context caching, so contexts related
    // only by non-caching adds cannot have changed any of them
    if (previous !== undefined && Context.hasSameCache(previous, context)) return;
    // Contexts sharing a cacheRoot resolve every cached key identically, so
    // the derived cache object is computed once per root and shared by all
    // fibers running with that root (forked fibers reuse the parent's).
    const root = context.cacheRoot;
    const cache = root._fiberCache ??= makeFiberContextCache(context);
    if (this.cache?.scheduler !== cache.scheduler) {
      this._dispatcher = undefined;
    }
    this.cache = cache;
  }
  get currentSpanLocal() {
    const span = this.cache.span;
    return span?._tag === "Span" ? span : undefined;
  }
}
const makeFiberContextCache = context => {
  // The string-keyed lookups keep the Tracer key values (and the native
  // tracer behind Tracer.Tracer's default) out of every bundle
  const currentTracer = Context.getOrUndefinedUnsafe(context, Tracer.TracerKey);
  return {
    scheduler: Context.get(context, Scheduler.Scheduler),
    tracer: currentTracer,
    tracerContext: currentTracer ? currentTracer["context"] : undefined,
    tracerEnabled: Context.get(context, TracerEnabled),
    span: Context.getOrUndefinedUnsafe(context, Tracer.ParentSpanKey),
    logLevel: Context.get(context, CurrentLogLevel),
    minimumLogLevel: Context.get(context, MinimumLogLevel),
    stackFrame: Context.get(context, CurrentStackFrame),
    runtimeMetrics: Context.getOrUndefinedUnsafe(context, InternalMetric.FiberRuntimeMetricsKey),
    maxOpsBeforeYield: Context.get(context, Scheduler.MaxOpsBeforeYield),
    preventYield: Context.get(context, Scheduler.PreventSchedulerYield)
  };
};
const deferredInterruptCont = {
  [contA](_value, fiber) {
    return failCause(fiber._interruptedCause);
  },
  [contE](_cause, fiber) {
    return failCause(fiber._interruptedCause);
  }
};
// must be a power of two
const maxInlineSteps = 32;
const fiberMiddleware = {
  interruptChildren: undefined
};
const fiberStackAnnotations = fiber => {
  if (!fiber.cache.stackFrame) return undefined;
  const annotations = new Map();
  annotations.set(InterruptorStackTrace.key, fiber.cache.stackFrame);
  return Context.makeUnsafe(annotations);
};
const fiberInterruptChildren = fiber => {
  if (fiber._children === undefined || fiber._children.size === 0) {
    return undefined;
  }
  return fiberInterruptAll(fiber._children);
};
/** @internal */
export const fiberAwait = self => {
  const impl = self;
  if (impl._exit) return succeed(impl._exit);
  return callback(resume => {
    if (impl._exit) return resume(succeed(impl._exit));
    return sync(self.addObserver(exit => resume(succeed(exit))));
  });
};
/** @internal */
export const fiberAwaitAll = self => callback(resume => {
  const iter = self[Symbol.iterator]();
  const exits = [];
  let cancel = undefined;
  function loop() {
    let result = iter.next();
    while (!result.done) {
      if (result.value._exit) {
        exits.push(result.value._exit);
        result = iter.next();
        continue;
      }
      cancel = result.value.addObserver(exit => {
        exits.push(exit);
        loop();
      });
      return;
    }
    resume(succeed(exits));
  }
  loop();
  return sync(() => cancel?.());
});
/** @internal */
export const fiberJoin = self => {
  const impl = self;
  if (impl._exit) return impl._exit;
  return callback(resume => {
    if (impl._exit) return resume(impl._exit);
    return sync(self.addObserver(resume));
  });
};
/** @internal */
export const fiberJoinAll = self => callback(resume => {
  const fibers = Array.from(self);
  if (fibers.length === 0) return resume(succeed(Arr.empty()));
  const out = new Array(fibers.length);
  const observers = Arr.empty();
  const removeObservers = () => {
    for (let i = 0; i < observers.length; i++) {
      fibers[i].removeObserver(observers[i]);
    }
  };
  let done = 0;
  let failed = false;
  for (let i = 0; i < fibers.length; i++) {
    if (failed) break;
    const observer = exit => {
      done++;
      if (exit._tag === "Failure") {
        failed = true;
        removeObservers();
        return resume(exit);
      }
      out[i] = exit.value;
      if (done === fibers.length) {
        resume(succeed(out));
      }
    };
    observers.push(observer);
    fibers[i].addObserver(observer);
  }
  return sync(() => {
    failed = true;
    removeObservers();
  });
});
/** @internal */
export const fiberInterrupt = self => withFiber(fiber => fiberInterruptAs(self, fiber.id));
/** @internal */
export const fiberInterruptAs = /*#__PURE__*/dual(args => hasProperty(args[0], FiberTypeId), (self, fiberId, annotations) => withFiber(parent => {
  let ann = fiberStackAnnotations(parent);
  ann = ann && annotations ? Context.merge(ann, annotations) : ann ?? annotations;
  self.interruptUnsafe(fiberId, ann);
  return asVoid(fiberAwait(self));
}));
/** @internal */
export const fiberInterruptAll = fibers => withFiber(parent => {
  const annotations = fiberStackAnnotations(parent);
  let fiberArr = Arr.empty();
  for (const fiber of fibers) {
    fiber.interruptUnsafe(parent.id, annotations);
    fiberArr.push(fiber);
  }
  return asVoid(fiberAwaitAll(fiberArr));
});
/** @internal */
export const fiberInterruptAllAs = /*#__PURE__*/dual(2, (fibers, fiberId) => withFiber(parent => {
  const annotations = fiberStackAnnotations(parent);
  const fiberArr = Arr.empty();
  for (const fiber of fibers) {
    fiber.interruptUnsafe(fiberId, annotations);
    fiberArr.push(fiber);
  }
  return asVoid(fiberAwaitAll(fiberArr));
}));
/** @internal */
export const succeed = exitSucceed;
/** @internal */
export const failCause = exitFailCause;
/** @internal */
export const fail = exitFail;
/** @internal */
export const sync = /*#__PURE__*/makePrimitive({
  op: "Sync",
  [evaluate](fiber) {
    const value = this[args]();
    const cont = fiber.getCont(contA);
    return cont ? cont[contA](value, fiber) : fiber.yieldWith(exitSucceed(value));
  }
});
/** @internal */
export const suspend = /*#__PURE__*/makePrimitive({
  op: "Suspend",
  [evaluate](_fiber) {
    return this[args]();
  }
});
/** @internal */
export const fromOption = /*#__PURE__*/dual(args => args.length >= 2 || Option.isOption(args[0]), (option, onNone) => Option.isNone(option) ? fail(onNone ? onNone() : new NoSuchElementError("Effect.fromOption: Option.none")) : succeed(option.value));
/** @internal */
export const fromResult = /*#__PURE__*/Result.match({
  onFailure: fail,
  onSuccess: succeed
});
/** @internal */
export const fromNullishOr = value => value == null ? fail(new NoSuchElementError()) : succeed(value);
/** @internal */
export const yieldNowWith = /*#__PURE__*/makePrimitive({
  op: "Yield",
  [evaluate](fiber) {
    let resumed = false;
    fiber.currentDispatcher.scheduleTask(() => {
      if (resumed) return;
      fiber.evaluate(exitVoid);
    }, this[args] ?? 0);
    return fiber.yieldWith(() => {
      resumed = true;
    });
  }
});
/** @internal */
export const yieldNow = /*#__PURE__*/yieldNowWith(0);
/** @internal */
export const succeedSome = a => succeed(Option.some(a));
/** @internal */
export const succeedNone = /*#__PURE__*/succeed(/*#__PURE__*/Option.none());
/** @internal */
export const transposeOption = self => Option.isNone(self) ? succeedNone : map(self.value, Option.some);
/** @internal */
export const failCauseSync = evaluate => suspend(() => failCause(evaluate()));
/** @internal */
export const die = defect => exitDie(defect);
/** @internal */
export const failSync = error => suspend(() => fail(error()));
/** @internal */
const void_ = /*#__PURE__*/succeed(void 0);
/** @internal */
export { void_ as void };
/** @internal */
const try_ = options => {
  const evaluate = typeof options === "function" ? options : options.try;
  const catcher = typeof options === "function" ? cause => new UnknownError(cause, "An error occurred in Effect.try") : options.catch;
  return suspend(() => {
    try {
      return succeed(evaluate());
    } catch (err) {
      return fail(catcher(err));
    }
  });
};
/** @internal */
export { try_ as try };
/** @internal */
export const promise = evaluate => callbackOptions(function (resume, signal) {
  evaluate(signal).then(a => resume(succeed(a)), e => resume(die(e)));
}, evaluate.length !== 0);
/** @internal */
export const tryPromise = options => {
  const f = typeof options === "function" ? options : options.try;
  const catcher = typeof options === "function" ? cause => new UnknownError(cause, "An error occurred in Effect.tryPromise") : options.catch;
  return callbackOptions(function (resume, signal) {
    // Defer the catcher until the fiber restores its async context.
    const failWithCatch = cause => suspend(() => {
      try {
        return fail(internalCall(() => catcher(cause)));
      } catch (err) {
        return die(err);
      }
    });
    try {
      f(signal).then(a => resume(succeed(a)), e => resume(failWithCatch(e)));
    } catch (err) {
      resume(failWithCatch(err));
    }
  }, f.length !== 0);
};
/** @internal */
export const withFiberId = f => withFiber(fiber => f(fiber.id));
/** @internal */
export const fiber = /*#__PURE__*/withFiber(succeed);
/** @internal */
export const fiberId = /*#__PURE__*/withFiberId(succeed);
const callbackOptions = /*#__PURE__*/function () {
  const Proto = /*#__PURE__*/makePrimitiveProto({
    op: "Async",
    [evaluate](fiber) {
      let resumed = false;
      let yielded = false;
      const controller = this.withSignal ? new AbortController() : undefined;
      const onCancel = this.register.call(fiber.cache.scheduler, effect => {
        if (resumed) return;
        resumed = true;
        if (yielded) {
          fiber.evaluate(effect);
        } else {
          yielded = effect;
        }
      }, controller?.signal);
      if (yielded !== false) return yielded;
      yielded = true;
      fiber._yielded = () => {
        resumed = true;
      };
      if (controller === undefined && onCancel === undefined) {
        return Yield;
      }
      fiber._stack.push(asyncFinalizer(() => {
        resumed = true;
        controller?.abort();
        return onCancel ?? exitVoid;
      }));
      return Yield;
    }
  });
  const AsyncImpl = function (register, withSignal) {
    this.register = register;
    this.withSignal = withSignal;
  };
  AsyncImpl.prototype = Proto;
  return function (register, withSignal) {
    return new AsyncImpl(register, withSignal);
  };
}();
const asyncFinalizer = /*#__PURE__*/makePrimitive({
  op: "AsyncFinalizer",
  [contAll](fiber) {
    if (fiber.interruptible) {
      fiber.interruptible = false;
      fiber._stack.push(setInterruptibleTrue);
    }
  },
  [contE](cause, _fiber) {
    return hasInterrupts(cause) ? flatMap(combineFinalizerCause(exitFailCause(cause), this[args]()), () => failCause(cause)) : failCause(cause);
  }
});
/** @internal */
export const callback = register => callbackOptions(register, register.length >= 2);
/** @internal */
export const never = /*#__PURE__*/callback(constVoid);
/** @internal */
export const gen = (...args) => {
  if (args.length === 1) {
    const body = args[0];
    return suspend(() => fromIteratorUnsafe(body()));
  }
  const [options, body] = args;
  return suspend(() => fromIteratorUnsafe(body.call(options.self)));
};
/** @internal */
export const fnUntraced = (body, ...pipeables) => {
  const fn = pipeables.length === 0 ? function () {
    return suspend(() => fromIteratorUnsafe(body.apply(this, arguments)));
  } : function () {
    let effect = suspend(() => fromIteratorUnsafe(body.apply(this, arguments)));
    for (let i = 0; i < pipeables.length; i++) {
      effect = pipeables[i](effect, ...arguments);
    }
    return effect;
  };
  return defineFunctionLength(body.length, fn);
};
const defineFunctionLength = (length, fn) => Object.defineProperty(fn, "length", {
  value: length,
  configurable: true
});
const fnStackCleaner = /*#__PURE__*/makeStackCleaner(2);
/** @internal */
export const fn = function () {
  const nameFirst = typeof arguments[0] === "string";
  const name = nameFirst ? arguments[0] : "Effect.fn";
  const spanOptions = nameFirst ? arguments[1] : undefined;
  const prevLimit = getStackTraceLimit();
  let defError;
  if (prevLimit !== 0) {
    setStackTraceLimit(2);
    defError = new globalThis.Error();
    setStackTraceLimit(prevLimit);
  }
  if (nameFirst) {
    return (body, ...pipeables) => makeFn(name, body, defError, pipeables, nameFirst, spanOptions);
  }
  return makeFn(name, arguments[0], defError, Array.prototype.slice.call(arguments, 1), nameFirst, spanOptions);
};
const makeFn = (name, bodyOrOptions, defError, pipeables, addSpan, spanOptions) => {
  const body = typeof bodyOrOptions === "function" ? bodyOrOptions : pipeables.shift().bind(bodyOrOptions.self);
  const definitionName = `${name} (definition)`;
  const definitionStack = defError ? fnStackCleaner(() => defError.stack) : constUndefined;
  return defineFunctionLength(body.length, function (...args) {
    let result = suspend(() => {
      const iter = body.apply(this, arguments);
      return isEffect(iter) ? iter : fromIteratorUnsafe(iter);
    });
    for (let i = 0; i < pipeables.length; i++) {
      result = pipeables[i](result, ...args);
    }
    if (!isEffect(result)) {
      return result;
    }
    const prevLimit = getStackTraceLimit();
    let callError;
    if (prevLimit !== 0) {
      setStackTraceLimit(2);
      callError = new globalThis.Error();
      setStackTraceLimit(prevLimit);
    }
    return updateService(addSpan ? useSpan(name, spanOptions, span => provideParentSpan(result, span)) : result, CurrentStackFrame, prev => ({
      name,
      stack: callError ? fnStackCleaner(() => callError.stack) : constUndefined,
      parent: {
        name: definitionName,
        stack: definitionStack,
        parent: prev
      }
    }));
  });
};
/** @internal */
export const fnUntracedEager = (body, ...pipeables) => defineFunctionLength(body.length, pipeables.length === 0 ? function () {
  return fromIteratorEagerUnsafe(() => body.apply(this, arguments));
} : function () {
  let effect = fromIteratorEagerUnsafe(() => body.apply(this, arguments));
  for (const pipeable of pipeables) {
    effect = pipeable(effect, ...arguments);
  }
  return effect;
});
const fromIteratorEagerUnsafe = evaluate => {
  try {
    const iterator = evaluate();
    let value = undefined;
    // Try to resolve synchronously in a loop
    while (true) {
      const state = iterator.next(value);
      if (state.done) {
        return succeed(state.value);
      }
      const primitive = state.value;
      if (primitive && primitive._tag === "Success") {
        value = primitive.value;
        continue;
      } else if (primitive && primitive._tag === "Failure") {
        return state.value;
      } else {
        let isFirstExecution = true;
        return suspend(() => {
          if (isFirstExecution) {
            isFirstExecution = false;
            return flatMap(state.value, value => fromIteratorUnsafe(iterator, value));
          } else {
            return suspend(() => fromIteratorUnsafe(evaluate()));
          }
        });
      }
    }
  } catch (error) {
    return die(error);
  }
};
const fromIteratorUnsafe = /*#__PURE__*/function () {
  const Proto = /*#__PURE__*/makePrimitiveProto({
    op: "Iterator",
    [contA](value, fiber) {
      const iter = this.iterator;
      while (true) {
        const state = iter.next(value);
        if (state.done) return succeed(state.value);
        if (!effectIsExit(state.value)) {
          fiber._stack.push(this);
          return state.value;
        } else if (state.value._tag === "Failure") {
          return state.value;
        }
        value = state.value.value;
      }
    },
    [evaluate](fiber) {
      return this[contA](this.initial, fiber);
    }
  });
  const IteratorImpl = function (iterator, initial) {
    this.iterator = iterator;
    this.initial = initial;
  };
  IteratorImpl.prototype = Proto;
  return function (iterator, initial) {
    return new IteratorImpl(iterator, initial);
  };
}();
// ----------------------------------------------------------------------------
// mapping & sequencing
// ----------------------------------------------------------------------------
/** @internal */
export const as = /*#__PURE__*/dual(2, (self, value) => new ContImpl(self, returnPayload, succeed(value)));
const evaluateCont = function (fiber) {
  fiber._stack.push(this);
  return this[args];
};
const OnSuccessProto = /*#__PURE__*/makePrimitiveProto({
  op: "OnSuccess",
  [evaluate]: evaluateCont
});
// A success continuation with an extra payload slot. The stored continuation
// receives the primitive as `this` and reads `this.payload`, so combinators
// like map / as / tap / andThen / flatMap can share module-level continuation
// functions instead of allocating a closure per call.
const ContImpl = function (self, cont, payload) {
  this[args] = self;
  this[contA] = cont;
  this.payload = payload;
};
ContImpl.prototype = OnSuccessProto;
const returnPayload = function () {
  return this.payload;
};
const succeedPayload = function (_value, fiber) {
  return fiber.succeedWith(this.payload);
};
// V8 includes the property name of a stored continuation in its stack trace.
// Other engines need an explicit frame for the stack cleaner to cut at.
const continuationMarksStack = /*#__PURE__*/(() => {
  const marker = "~effect/Effect/stackProbe";
  const probe = {
    [marker]: function stackProbe() {
      return new Error().stack;
    }
  };
  return probe[marker]()?.includes("[as " + marker + "]") === true;
})();
const mapCont = function (value, fiber) {
  const f = this.payload;
  return fiber.succeedWith(continuationMarksStack ? f(value) : internalCall(() => f(value)));
};
const andThenCont = function (value) {
  const f = this.payload;
  return f(value);
};
const tapCont = function (value) {
  const f = this.payload;
  return new ContImpl(f(value), succeedPayload, value);
};
const tapEffectCont = function (value) {
  return new ContImpl(this.payload, succeedPayload, value);
};
/** @internal */
export const asSome = self => map(self, Option.some);
/** @internal */
export const flip = self => matchEffect(self, {
  onFailure: succeed,
  onSuccess: fail
});
/** @internal */
export const andThen = /*#__PURE__*/dual(2, (self, f) => new ContImpl(self, isEffect(f) ? returnPayload : andThenCont, f));
/** @internal */
export const tap = /*#__PURE__*/dual(2, (self, f) => new ContImpl(self, isEffect(f) ? tapEffectCont : tapCont, f));
/** @internal */
export const asVoid = self => new ContImpl(self, returnPayload, exitVoid);
/** @internal */
export const sandbox = self => catchCause(self, fail);
/** @internal */
export const raceAll = (all, options) => withFiber(parent => {
  const fibers = new Set();
  // Read fibers on exit to include losers forked after the race settles.
  onExitUnsafe(parent, () => fibers.size === 0 ? undefined : fiberInterruptAll(fibers));
  return callback(resume => {
    const effects = Arr.fromIterable(all);
    const len = effects.length;
    let doneCount = 0;
    let done = false;
    const failures = [];
    const onExit = (exit, fiber, i) => {
      doneCount++;
      if (exit._tag === "Failure") {
        failures.push(...exit.cause.reasons);
        if (doneCount >= len) {
          resume(failCause(causeFromReasons(failures)));
        }
        return;
      }
      const isWinner = !done;
      done = true;
      resume(exit);
      if (isWinner && options?.onWinner) {
        options.onWinner({
          fiber,
          index: i,
          parentFiber: parent
        });
      }
    };
    for (let i = 0; i < len; i++) {
      const fiber = forkUnsafe(parent, effects[i], true, true, false);
      fibers.add(fiber);
      fiber.addObserver(exit => {
        fibers.delete(fiber);
        onExit(exit, fiber, i);
      });
      if (done) break;
    }
  });
});
/** @internal */
export const raceAllFirst = (all, options) => withFiber(parent => {
  const fibers = new Set();
  onExitUnsafe(parent, () => fibers.size === 0 ? undefined : fiberInterruptAll(fibers));
  return callback(resume => {
    let done = false;
    let i = 0;
    for (const effect of all) {
      if (done) break;
      const index = i++;
      const fiber = forkUnsafe(parent, effect, true, true, false);
      fibers.add(fiber);
      fiber.addObserver(exit => {
        fibers.delete(fiber);
        const isWinner = !done;
        done = true;
        resume(exit);
        if (isWinner && options?.onWinner) {
          options.onWinner({
            fiber,
            index,
            parentFiber: parent
          });
        }
      });
    }
  });
});
/** @internal */
export const race = /*#__PURE__*/dual(args => isEffect(args[1]), (self, that, options) => raceAll([self, that], options));
/** @internal */
export const raceFirst = /*#__PURE__*/dual(args => isEffect(args[1]), (self, that, options) => raceAllFirst([self, that], options));
/** @internal */
export const flatMap = /*#__PURE__*/dual(2, (self, f) => new ContImpl(self, andThenCont, f));
/** @internal */
export const matchCauseEffectEager = /*#__PURE__*/dual(2, (self, options) => {
  if (effectIsExit(self)) {
    return self._tag === "Success" ? options.onSuccess(self.value) : options.onFailure(self.cause);
  }
  return matchCauseEffect(self, options);
});
/** @internal */
export const effectIsExit = effect => effect[ExitTypeId] !== undefined;
/** @internal */
export const flatMapEager = /*#__PURE__*/dual(2, (self, f) => {
  if (effectIsExit(self)) {
    return self._tag === "Success" ? f(self.value) : self;
  }
  return flatMap(self, f);
});
// ----------------------------------------------------------------------------
// mapping & sequencing
// ----------------------------------------------------------------------------
/** @internal */
export const flatten = self => flatMap(self, identity);
/** @internal */
export const map = /*#__PURE__*/dual(2, (self, f) => new ContImpl(self, mapCont, f));
/** @internal */
export const mapEager = /*#__PURE__*/dual(2, (self, f) => effectIsExit(self) ? exitMap(self, f) : map(self, f));
/** @internal */
export const mapErrorEager = /*#__PURE__*/dual(2, (self, f) => effectIsExit(self) ? exitMapError(self, f) : mapError(self, f));
/** @internal */
export const mapBothEager = /*#__PURE__*/dual(2, (self, options) => effectIsExit(self) ? exitMapBoth(self, options) : mapBoth(self, options));
/** @internal */
export const catchEager = /*#__PURE__*/dual(2, (self, f) => {
  if (effectIsExit(self)) {
    if (self._tag === "Success") return self;
    const error = findError(self.cause);
    if (Result.isFailure(error)) return self;
    return f(error.success);
  }
  return catch_(self, f);
});
// ----------------------------------------------------------------------------
// Exit
// ----------------------------------------------------------------------------
/** @internal */
export const exitInterrupt = fiberId => exitFailCause(causeInterrupt(fiberId));
/** @internal */
export const exitIsSuccess = self => self._tag === "Success";
/** @internal */
export const exitFilterSuccess = self => self._tag === "Success" ? Result.succeed(self) : Result.fail(self);
/** @internal */
export const exitFilterValue = self => self._tag === "Success" ? Result.succeed(self.value) : Result.fail(self);
/** @internal */
export const exitIsFailure = self => self._tag === "Failure";
/** @internal */
export const exitFilterFailure = self => self._tag === "Failure" ? Result.succeed(self) : Result.fail(self);
/** @internal */
export const exitFilterCause = self => self._tag === "Failure" ? Result.succeed(self.cause) : Result.fail(self);
/** @internal */
export const exitFindError = /*#__PURE__*/Filter.composePassthrough(exitFilterCause, findError);
/** @internal */
export const exitFindDefect = /*#__PURE__*/Filter.composePassthrough(exitFilterCause, findDefect);
/** @internal */
export const exitHasInterrupts = self => self._tag === "Failure" && hasInterrupts(self.cause);
/** @internal */
export const exitHasDies = self => self._tag === "Failure" && hasDies(self.cause);
/** @internal */
export const exitHasFails = self => self._tag === "Failure" && hasFails(self.cause);
/** @internal */
export const exitVoid = /*#__PURE__*/exitSucceed(void 0);
/** @internal */
export const exitMap = /*#__PURE__*/dual(2, (self, f) => self._tag === "Success" ? exitSucceed(f(self.value)) : self);
/** @internal */
export const exitMapError = /*#__PURE__*/dual(2, (self, f) => {
  if (self._tag === "Success") return self;
  const error = findError(self.cause);
  if (Result.isFailure(error)) return self;
  return exitFail(f(error.success));
});
/** @internal */
export const exitMapBoth = /*#__PURE__*/dual(2, (self, options) => {
  if (self._tag === "Success") return exitSucceed(options.onSuccess(self.value));
  const error = findError(self.cause);
  if (Result.isFailure(error)) return self;
  return exitFail(options.onFailure(error.success));
});
/** @internal */
export const exitAs = /*#__PURE__*/dual(2, (self, b) => exitIsSuccess(self) ? exitSucceed(b) : self);
/** @internal */
export const exitZipRight = /*#__PURE__*/dual(2, (self, that) => exitIsSuccess(self) ? that : self);
/** @internal */
export const exitMatch = /*#__PURE__*/dual(2, (self, options) => exitIsSuccess(self) ? options.onSuccess(self.value) : options.onFailure(self.cause));
/** @internal */
export const exitAsVoid = /*#__PURE__*/exitAs(void 0);
/** @internal */
export const exitAsVoidAll = exits => {
  const failures = [];
  for (const exit of exits) {
    if (exit._tag === "Failure") {
      failures.push(...exit.cause.reasons);
    }
  }
  return failures.length === 0 ? exitVoid : exitFailCause(causeFromReasons(failures));
};
/** @internal */
export const exitGetSuccess = self => exitIsSuccess(self) ? Option.some(self.value) : Option.none();
/** @internal */
export const exitGetCause = self => exitIsFailure(self) ? Option.some(self.cause) : Option.none();
/** @internal */
export const exitFindErrorOption = self => {
  const error = exitFindError(self);
  return Result.isFailure(error) ? Option.none() : Option.some(error.success);
};
// ----------------------------------------------------------------------------
// environment
// ----------------------------------------------------------------------------
/** @internal */
export const service = service => service;
/** @internal */
export const serviceOption = service => withFiber(fiber => succeed(Context.getOption(fiber.context, service)));
/** @internal */
export const serviceOptional = service => withFiber(fiber => fromOption(Context.getOption(fiber.context, service)));
/** @internal */
export const updateContext = /*#__PURE__*/dual(2, (self, f) => withFiber(fiber => {
  const prevContext = fiber.context;
  const nextContext = f(prevContext);
  if (prevContext === nextContext) return self;
  fiber.setContext(nextContext);
  onExitUnsafe(fiber, () => {
    fiber.setContext(prevContext);
    return undefined;
  });
  return self;
}));
/** @internal */
export const updateService = /*#__PURE__*/dual(3, (self, service, f) => updateContext(self, s => {
  const prev = Context.getUnsafe(s, service);
  const next = f(prev);
  if (prev === next) return s;
  return Context.add(s, service, next);
}));
/** @internal */
export const updateServiceScoped = (service, update, options) => uninterruptible(withFiber(fiber => {
  const original = Context.getUnsafe(fiber.context, service);
  const updated = update(original);
  fiber.setContext(Context.add(fiber.context, service, updated));
  return scopeAddFinalizerExit(Context.getUnsafe(fiber.context, scopeTag), _ => {
    const currentOption = Context.getOption(fiber.context, service);
    if (Option.isNone(currentOption)) return void_;
    const current = currentOption.value;
    let next;
    if (options?.reset === undefined) {
      if (current !== updated) return void_;
      next = original;
    } else {
      next = options.reset(original, updated, current);
    }
    fiber.setContext(Context.add(fiber.context, service, next));
    return void_;
  });
}));
/** @internal */
export const context = () => getContext;
const getContext = /*#__PURE__*/withFiber(fiber => succeed(fiber.context));
/** @internal */
export const contextWith = f => withFiber(fiber => f(fiber.context));
/** @internal */
export const setContext = /*#__PURE__*/dual(2, (self, context) => updateContext(self, constant(context)));
/** @internal */
export const provideContext = /*#__PURE__*/dual(2, (self, context) => {
  if (effectIsExit(self)) return self;
  return updateContext(self, Context.merge(context));
});
/** @internal */
export const provideService = function () {
  if (arguments.length === 1) {
    return dual(2, (self, impl) => provideServiceImpl(self, arguments[0], impl));
  }
  return dual(3, (self, service, impl) => provideServiceImpl(self, service, impl)).apply(this, arguments);
};
const provideServiceImpl = (self, service, implementation) => updateContext(self, Context.add(service, implementation));
/** @internal */
export const provideServiceEffect = /*#__PURE__*/dual(3, (self, service, acquire) => flatMap(acquire, implementation => provideService(self, service, implementation)));
// ----------------------------------------------------------------------------
// zipping
// ----------------------------------------------------------------------------
/** @internal */
export const zip = /*#__PURE__*/dual(args => isEffect(args[1]), (self, that, options) => zipWith(self, that, (a, a2) => [a, a2], options));
/** @internal */
export const zipWith = /*#__PURE__*/dual(args => isEffect(args[1]), (self, that, f, options) => options?.concurrent
// Use `all` exclusively for concurrent cases, as it introduces additional overhead due to the management of concurrency
? map(all([self, that], {
  concurrency: 2
}), ([a, a2]) => f(a, a2)) : flatMap(self, a => map(that, a2 => f(a, a2))));
// ----------------------------------------------------------------------------
// filtering & conditionals
// ----------------------------------------------------------------------------
/** @internal */
export const filterOrFail = /*#__PURE__*/dual(args => isEffect(args[0]), (self, predicate, orFailWith) => filterOrElse(self, predicate, orFailWith ? a => fail(orFailWith(a)) : () => fail(new NoSuchElementError())));
/** @internal */
export const when = /*#__PURE__*/dual(2, (self, condition) => flatMap(condition, pass => pass ? asSome(self) : succeedNone));
// ----------------------------------------------------------------------------
// repetition
// ----------------------------------------------------------------------------
/** @internal */
export const replicate = /*#__PURE__*/dual(2, (self, n) => Array.from({
  length: n
}, () => self));
/** @internal */
export const replicateEffect = /*#__PURE__*/dual(args => isEffect(args[0]), (self, n, options) => all(replicate(self, n), options));
/** @internal */
export const forever = /*#__PURE__*/dual(args => isEffect(args[0]), (self, options) => whileLoop({
  while: constTrue,
  body: constant(options?.disableYield ? self : flatMap(self, _ => yieldNow)),
  step: constVoid
}));
// ----------------------------------------------------------------------------
// error handling
// ----------------------------------------------------------------------------
/** @internal */
export const catchCause = /*#__PURE__*/dual(2, (self, f) => new OnFailureImpl(self, f.length !== 1 ? cause => f(cause) : f));
const OnFailureProto = /*#__PURE__*/makePrimitiveProto({
  op: "OnFailure",
  [evaluate]: evaluateCont
});
const OnFailureImpl = function (self, f) {
  this[args] = self;
  this[contE] = f;
};
OnFailureImpl.prototype = OnFailureProto;
/** @internal */
export const catchCauseIf = /*#__PURE__*/dual(3, (self, predicate, f) => catchCause(self, cause => {
  if (!predicate(cause)) {
    return failCause(cause);
  }
  return f(cause);
}));
/** @internal */
export const catchCauseFilter = /*#__PURE__*/dual(3, (self, filter, f) => catchCause(self, cause => {
  const eb = filter(cause);
  return Result.isFailure(eb) ? failCause(eb.failure) : f(eb.success, cause);
}));
/** @internal */
export const catch_ = /*#__PURE__*/dual(2, (self, f) => catchCauseFilter(self, findError, e => f(e)));
/** @internal */
export const catchNoSuchElement = self => matchEffect(self, {
  onFailure: error => isNoSuchElementError(error) ? succeedNone : fail(error),
  onSuccess: succeedSome
});
/** @internal */
export const catchDefect = /*#__PURE__*/dual(2, (self, f) => catchCauseFilter(self, findDefect, f));
/** @internal */
export const tapCause = /*#__PURE__*/dual(2, (self, f) => catchCause(self, cause => andThen(f(cause), failCause(cause))));
/** @internal */
export const tapCauseIf = /*#__PURE__*/dual(3, (self, predicate, f) => catchCauseIf(self, predicate, cause => andThen(f(cause), failCause(cause))));
/** @internal */
export const tapCauseFilter = /*#__PURE__*/dual(3, (self, filter, f) => catchCause(self, cause => {
  const result = filter(cause);
  if (Result.isFailure(result)) {
    return failCause(cause);
  }
  return andThen(f(result.success, cause), failCause(cause));
}));
/** @internal */
export const tapError = /*#__PURE__*/dual(2, (self, f) => tapCauseFilter(self, findError, e => f(e)));
/** @internal */
export const tapErrorTag = /*#__PURE__*/dual(3, (self, k, f) => {
  const predicate = Array.isArray(k) ? e => hasProperty(e, "_tag") && k.includes(e._tag) : isTagged(k);
  return tapError(self, error => predicate(error) ? f(error) : void_);
});
/** @internal */
export const tapDefect = /*#__PURE__*/dual(2, (self, f) => tapCauseFilter(self, findDefect, _ => f(_)));
/** @internal */
export const catchIf = /*#__PURE__*/dual(args => isEffect(args[0]), (self, predicate, f, orElse) => catchCause(self, cause => {
  const error = findError(cause);
  if (Result.isFailure(error)) return failCause(error.failure);
  if (!predicate(error.success)) {
    return orElse ? orElse(error.success) : failCause(cause);
  }
  return f(error.success);
}));
/** @internal */
export const catchFilter = /*#__PURE__*/dual(args => isEffect(args[0]), (self, filter, f, orElse) => catchCause(self, cause => {
  const error = findError(cause);
  if (Result.isFailure(error)) return failCause(error.failure);
  const result = filter(error.success);
  if (Result.isFailure(result)) {
    return orElse ? orElse(result.failure) : failCause(cause);
  }
  return f(result.success);
}));
/** @internal */
export const catchTag = /*#__PURE__*/dual(args => isEffect(args[0]), (self, k, f, orElse) => {
  const pred = Array.isArray(k) ? e => hasProperty(e, "_tag") && k.includes(e._tag) : isTagged(k);
  return catchIf(self, pred, f, orElse);
});
/** @internal */
export const catchTags = /*#__PURE__*/dual(args => isEffect(args[0]), (self, cases, orElse) => {
  let keys;
  return catchFilter(self, e => {
    keys ??= Object.keys(cases);
    return hasProperty(e, "_tag") && isString(e["_tag"]) && keys.includes(e["_tag"]) ? Result.succeed(e) : Result.fail(e);
  }, e => cases[e["_tag"]](e), orElse);
});
/** @internal */
export const catchReason = /*#__PURE__*/dual(args => isEffect(args[0]), (self, errorTag, reasonTag, f, orElse) => catchIf(self, e => isTagged(e, errorTag) && hasProperty(e, "reason") && (orElse !== undefined || isTagged(e.reason, reasonTag)), e => {
  const reason = e.reason;
  if (isTagged(reason, reasonTag)) return f(reason, e);
  return orElse ? orElse(reason, e) : fail(e);
}));
/** @internal */
export const catchReasons = /*#__PURE__*/dual(args => isEffect(args[0]), (self, errorTag, cases, orElse) => {
  let keys;
  return catchIf(self, e => isTagged(e, errorTag) && hasProperty(e, "reason") && hasProperty(e.reason, "_tag") && isString(e.reason._tag) && (orElse !== undefined || (keys ??= Object.keys(cases)).includes(e.reason._tag)), e => {
    const reason = e.reason;
    keys ??= Object.keys(cases);
    if (keys.includes(reason._tag)) {
      return cases[reason._tag](reason, e);
    }
    return orElse ? orElse(reason, e) : fail(e);
  });
});
/** @internal */
export const unwrapReason = /*#__PURE__*/dual(2, (self, errorTag) => catchFilter(self, e => {
  if (isTagged(e, errorTag) && hasProperty(e, "reason")) {
    return Result.succeed(e.reason);
  }
  return Result.fail(e);
}, fail));
/** @internal */
export const mapError = /*#__PURE__*/dual(2, (self, f) => catch_(self, error => failSync(() => f(error))));
/** @internal */
export const mapBoth = /*#__PURE__*/dual(2, (self, options) => matchEffect(self, {
  onFailure: e => failSync(() => options.onFailure(e)),
  onSuccess: a => sync(() => options.onSuccess(a))
}));
/** @internal */
export const orDie = self => catch_(self, die);
/** @internal */
export const orElseSucceed = /*#__PURE__*/dual(2, (self, f) => catch_(self, error => sync(() => f(error))));
/** @internal */
export const firstSuccessOf = effects => suspend(() => {
  const iterator = effects[Symbol.iterator]();
  let state = iterator.next();
  if (state.done) {
    return die(new Error("Received an empty collection of effects"));
  }
  function loop(current) {
    const next = iterator.next();
    if (next.done) return current.value;
    return catch_(current.value, _ => loop(next));
  }
  return loop(state);
});
/** @internal */
export const eventually = self => catch_(self, _ => flatMap(yieldNow, () => eventually(self)));
/** @internal */
export const ignore = /*#__PURE__*/dual(args => isEffect(args[0]), (self, options) => {
  if (!options?.log) {
    return matchEffect(self, {
      onFailure: _ => void_,
      onSuccess: _ => void_
    });
  }
  const logEffect = logWithLevel(options.log === true ? undefined : options.log);
  return matchCauseEffect(self, {
    onFailure(cause) {
      const failure = findFail(cause);
      return Result.isFailure(failure) ? failCause(failure.failure) : options.message === undefined ? logEffect(cause) : logEffect(options.message, cause);
    },
    onSuccess: _ => void_
  });
});
/** @internal */
export const ignoreCause = /*#__PURE__*/dual(args => isEffect(args[0]), (self, options) => {
  if (!options?.log) {
    return matchCauseEffect(self, {
      onFailure: _ => void_,
      onSuccess: _ => void_
    });
  }
  const logEffect = logWithLevel(options.log === true ? undefined : options.log);
  return matchCauseEffect(self, {
    onFailure: cause => options.message === undefined ? logEffect(cause) : logEffect(options.message, cause),
    onSuccess: _ => void_
  });
});
/** @internal */
export const option = self => match(self, {
  onFailure: Option.none,
  onSuccess: Option.some
});
/** @internal */
export const result = self => matchEager(self, {
  onFailure: Result.fail,
  onSuccess: Result.succeed
});
// ----------------------------------------------------------------------------
// pattern matching
// ----------------------------------------------------------------------------
/** @internal */
export const matchCauseEffect = /*#__PURE__*/dual(2, (self, options) => new OnSuccessAndFailureImpl(self, options.onSuccess.length !== 1 ? a => options.onSuccess(a) : options.onSuccess, options.onFailure.length !== 1 ? cause => options.onFailure(cause) : options.onFailure));
const OnSuccessAndFailureProto = /*#__PURE__*/makePrimitiveProto({
  op: "OnSuccessAndFailure",
  [evaluate]: evaluateCont
});
const OnSuccessAndFailureImpl = function (self, onSuccess, onFailure) {
  this[args] = self;
  this[contA] = onSuccess;
  this[contE] = onFailure;
};
OnSuccessAndFailureImpl.prototype = OnSuccessAndFailureProto;
// `match` and `matchCause` keep the caller's handlers object as the frame's
// payload and call it from the prototype, so no closure is built per call.
const matchSuccess = function (value, fiber) {
  const handlers = this.payload;
  return fiber.succeedWith(continuationMarksStack ? handlers.onSuccess(value) : internalCall(() => handlers.onSuccess(value)));
};
const makeMatch = (op, onFailure) => {
  const Proto = makePrimitiveProto({
    op,
    [evaluate]: evaluateCont,
    [contA]: matchSuccess,
    [contE]: onFailure
  });
  const MatchImpl = function (self, handlers) {
    this[args] = self;
    this.payload = handlers;
  };
  MatchImpl.prototype = Proto;
  return MatchImpl;
};
const MatchImpl = /*#__PURE__*/makeMatch("Match", function (cause, fiber) {
  const fail = cause.reasons.find(isFailReason);
  if (fail === undefined) return failCause(cause);
  const handlers = this.payload;
  return fiber.succeedWith(continuationMarksStack ? handlers.onFailure(fail.error) : internalCall(() => handlers.onFailure(fail.error)));
});
const MatchCauseImpl = /*#__PURE__*/makeMatch("MatchCause", function (cause, fiber) {
  const handlers = this.payload;
  return fiber.succeedWith(continuationMarksStack ? handlers.onFailure(cause) : internalCall(() => handlers.onFailure(cause)));
});
/** @internal */
export const matchCause = /*#__PURE__*/dual(2, (self, options) => new MatchCauseImpl(self, options));
/** @internal */
export const matchEffect = /*#__PURE__*/dual(2, (self, options) => matchCauseEffect(self, {
  onFailure: cause => {
    const fail = cause.reasons.find(isFailReason);
    return fail ? options.onFailure(fail.error) : failCause(cause);
  },
  onSuccess: options.onSuccess
}));
/** @internal */
export const match = /*#__PURE__*/dual(2, (self, options) => new MatchImpl(self, options));
/** @internal */
export const matchEager = /*#__PURE__*/dual(2, (self, options) => {
  if (effectIsExit(self)) {
    if (self._tag === "Success") return exitSucceed(options.onSuccess(self.value));
    const error = findError(self.cause);
    if (Result.isFailure(error)) return self;
    return exitSucceed(options.onFailure(error.success));
  }
  return match(self, options);
});
/** @internal */
export const matchCauseEager = /*#__PURE__*/dual(2, (self, options) => {
  if (effectIsExit(self)) {
    if (self._tag === "Success") return exitSucceed(options.onSuccess(self.value));
    return exitSucceed(options.onFailure(self.cause));
  }
  return matchCause(self, options);
});
/** @internal */
export const exit = self => effectIsExit(self) ? exitSucceed(self) : exitPrimitive(self);
const exitPrimitive = /*#__PURE__*/makePrimitive({
  op: "Exit",
  [evaluate](fiber) {
    fiber._stack.push(this);
    return this[args];
  },
  [contA](value, fiber, exit) {
    return fiber.succeedWith(exit ?? exitSucceed(value));
  },
  [contE](cause, fiber, exit) {
    return fiber.succeedWith(exit ?? exitFailCause(cause));
  }
});
// ----------------------------------------------------------------------------
// Condition checking
// ----------------------------------------------------------------------------
/** @internal */
export const isFailure = /*#__PURE__*/matchEager({
  onFailure: () => true,
  onSuccess: () => false
});
/** @internal */
export const isSuccess = /*#__PURE__*/matchEager({
  onFailure: () => false,
  onSuccess: () => true
});
// ----------------------------------------------------------------------------
// delays & timeouts
// ----------------------------------------------------------------------------
/** @internal */
export const delay = /*#__PURE__*/dual(2, (self, duration) => andThen(sleep(duration), self));
/** @internal */
export const timeoutOrElse = /*#__PURE__*/dual(2, (self, options) => flatMap(timeoutOption(self, options.duration), option => Option.isNone(option) ? options.orElse() : succeed(option.value)));
/** @internal */
const timeoutErrorFromDuration = duration => new TimeoutError(`Operation timed out after '${Duration.format(duration)}'`);
/** @internal */
export const timeout = /*#__PURE__*/dual(2, (self, duration) => {
  const decoded = Duration.fromInputUnsafe(duration);
  return timeoutOrElse(self, {
    duration: decoded,
    orElse: () => fail(timeoutErrorFromDuration(decoded))
  });
});
/** @internal */
export const timeoutOption = /*#__PURE__*/dual(2, (self, duration) => raceFirst(asSome(self), as(sleep(duration), Option.none())));
/** @internal */
export const timed = self => clockWith(clock => {
  const start = clock.monotonicTimeNanosUnsafe();
  return map(self, a => [Duration.nanos(clock.monotonicTimeNanosUnsafe() - start), a]);
});
// ----------------------------------------------------------------------------
// resources & finalization
// ----------------------------------------------------------------------------
/** @internal */
export const ScopeTypeId = "~effect/Scope";
/** @internal */
export const ScopeCloseableTypeId = "~effect/Scope/Closeable";
/** @internal */
export const scopeTag = /*#__PURE__*/Context.Service("effect/Scope");
/** @internal */
export const scopeClose = (self, exit_) => withFiber(fiber => {
  const close = scopeCloseUnsafe(self, exit_);
  if (close === undefined) return void_;
  fiberEnterUninterruptibleUnsafe(fiber);
  return close;
});
/** @internal */
export const scopeCloseUnsafe = (self, exit_) => {
  const state = self.state;
  if (state._tag === "Closed") return;
  self.state = {
    _tag: "Closed",
    exit: exit_
  };
  if (self.parent !== undefined) {
    scopeRemoveFinalizerUnsafe(self.parent, self);
  }
  if (state._tag === "Empty") return;
  if (state.finalizer !== undefined) {
    return runFinalizer(state.finalizer, exit_);
  }
  const finalizers = state.finalizers;
  if (finalizers.size === 1) {
    return runFinalizer(finalizers.values().next().value, exit_);
  }
  return scopeCloseFinalizers(self, finalizers, exit_);
};
const runFinalizer = (finalizer, exit_) => {
  try {
    return finalizer(exit_);
  } catch (defect) {
    return exitDie(defect);
  }
};
const combineFinalizerCause = (exit_, finalizer) => exitIsSuccess(exit_) ? finalizer : catchCause(finalizer, cause => failCause(causeCombine(exit_.cause, cause)));
const scopeCloseFinalizers = /*#__PURE__*/fnUntraced(function* (self, finalizers, exit_) {
  let exits = [];
  const fibers = [];
  const arr = Array.from(finalizers.values());
  const parent = getCurrentFiber();
  for (let i = arr.length - 1; i >= 0; i--) {
    const finalizer = arr[i];
    if (self.strategy === "sequential") {
      exits.push(yield* exit(runFinalizer(finalizer, exit_)));
    } else {
      fibers.push(forkUnsafe(parent, runFinalizer(finalizer, exit_), true, true, "inherit"));
    }
  }
  if (fibers.length > 0) {
    exits = yield* fiberAwaitAll(fibers);
  }
  return yield* exitAsVoidAll(exits);
});
/** @internal */
export const scopeFork = (scope, finalizerStrategy) => sync(() => scopeForkUnsafe(scope, finalizerStrategy));
/** @internal */
export const scopeForkUnsafe = (scope, finalizerStrategy) => {
  const child = makeScope(finalizerStrategy, scope);
  if (scope.state._tag === "Closed") {
    child.state = scope.state;
    return child;
  }
  scopeAddFinalizerUnsafe(scope, child, exit => scopeClose(child, exit));
  return child;
};
/** @internal */
export const scopeAddFinalizerExit = (scope, finalizer) => {
  return suspend(() => {
    if (scope.state._tag === "Closed") {
      return finalizer(scope.state.exit);
    }
    scopeAddFinalizerUnsafe(scope, {}, finalizer);
    return void_;
  });
};
/** @internal */
export const scopeAddFinalizer = (scope, finalizer) => scopeAddFinalizerExit(scope, constant(finalizer));
/** @internal */
export const scopeAddFinalizerUnsafe = (scope, key, finalizer) => {
  if (scope.state._tag === "Empty") {
    scope.state = {
      _tag: "Open",
      finalizerKey: key,
      finalizer,
      finalizers: undefined
    };
  } else if (scope.state._tag === "Open") {
    const state = scope.state;
    if (state.finalizer !== undefined) {
      state.finalizers = new Map([[state.finalizerKey, state.finalizer]]);
      state.finalizerKey = undefined;
      state.finalizer = undefined;
      state.finalizers.set(key, finalizer);
    } else {
      state.finalizers.set(key, finalizer);
    }
  }
};
/** @internal */
export const scopeRemoveFinalizerUnsafe = (scope, key) => {
  if (scope.state._tag !== "Open") return;
  const state = scope.state;
  if (state.finalizerKey === key) {
    scope.state = constScopeEmpty;
  } else if (state.finalizers !== undefined) {
    state.finalizers.delete(key);
    if (state.finalizers.size === 0) {
      scope.state = constScopeEmpty;
    }
  }
};
/** @internal */
export const scopeMakeUnsafe = finalizerStrategy => makeScope(finalizerStrategy, undefined);
const makeScope = (finalizerStrategy = "sequential", parent) => ({
  [ScopeCloseableTypeId]: ScopeCloseableTypeId,
  [ScopeTypeId]: ScopeTypeId,
  strategy: finalizerStrategy,
  parent,
  state: constScopeEmpty
});
const constScopeEmpty = {
  _tag: "Empty"
};
/** @internal */
export const scopeMake = finalizerStrategy => sync(() => scopeMakeUnsafe(finalizerStrategy));
/** @internal */
export const scope = scopeTag;
/** @internal */
export const provideScope = /*#__PURE__*/provideService(scopeTag);
/** @internal */
export const scoped = self => withFiber(fiber => {
  const prev = fiber.context;
  const scope = scopeMakeUnsafe();
  fiber.setContext(Context.add(fiber.context, scopeTag, scope));
  onExitUnsafe(fiber, exit => {
    fiber.setContext(prev);
    return scopeCloseUnsafe(scope, exit);
  });
  return self;
});
/** @internal */
export const scopeUse = /*#__PURE__*/dual(2, (self, scope) => onExit(provideScope(self, scope), exit => suspend(() => scopeCloseUnsafe(scope, exit) ?? void_)));
/** @internal */
export const scopedWith = f => suspend(() => {
  const scope = scopeMakeUnsafe();
  return onExit(f(scope), exit => suspend(() => scopeCloseUnsafe(scope, exit) ?? void_));
});
/** @internal */
export const acquireRelease = (acquire, release, options) => contextWith(context => uninterruptibleMask(restore => flatMap(scope, scope => tap(options?.interruptible ? restore(acquire) : acquire, a => scopeAddFinalizerExit(scope, exit => provideContext(release(a, exit), context))))));
/** @internal */
export const addFinalizer = finalizer => flatMap(scope, scope => contextWith(context => scopeAddFinalizerExit(scope, exit => provideContext(finalizer(exit), context))));
const OnExitImpl = /*#__PURE__*/function () {
  const Proto = /*#__PURE__*/makePrimitiveProto({
    op: "OnExit",
    [evaluate](fiber) {
      fiber._stack.push(this);
      return this.effect;
    },
    [contAll](fiber) {
      if (fiber.interruptible && this.interruptible !== true) {
        fiber._stack.push(setInterruptibleTrue);
        fiber.interruptible = false;
      }
    },
    [contA](value, _, exit) {
      exit ??= exitSucceed(value);
      let eff;
      try {
        eff = this.onExit(exit);
      } catch (defect) {
        eff = exitDie(defect);
      }
      return eff ? flatMap(eff, _ => exit) : exit;
    },
    [contE](cause, _, exit) {
      exit ??= exitFailCause(cause);
      let eff;
      try {
        eff = this.onExit(exit);
      } catch (defect) {
        eff = exitDie(defect);
      }
      return eff ? flatMap(combineFinalizerCause(exit, eff), _ => exit) : exit;
    }
  });
  const OnExitImpl = function (effect, onExit, interruptible) {
    this.effect = effect;
    this.onExit = onExit;
    this.interruptible = interruptible;
  };
  OnExitImpl.prototype = Proto;
  return OnExitImpl;
}();
/** @internal */
export const onExitPrimitive = (effect, onExit, interruptible) => new OnExitImpl(effect, onExit, interruptible);
/**
 * Pushes an exit finalizer for the current `withFiber` evaluation. Only call inside `withFiber`.
 * @internal
 */
export const onExitUnsafe = (fiber, f) => {
  ;
  fiber._stack.push(new OnExitImpl(undefined, f, undefined));
};
/** @internal */
export const onExit = /*#__PURE__*/dual(2, onExitPrimitive);
/** @internal */
export const ensuring = /*#__PURE__*/dual(2, (self, finalizer) => onExit(self, _ => finalizer));
/** @internal */
export const onExitIf = /*#__PURE__*/dual(3, (self, predicate, f) => onExit(self, exit => {
  if (!predicate(exit)) {
    return void_;
  }
  return f(exit);
}));
/** @internal */
export const onExitFilter = /*#__PURE__*/dual(3, (self, filter, f) => onExit(self, exit => {
  const b = filter(exit);
  return Result.isFailure(b) ? void_ : f(b.success, exit);
}));
/** @internal */
export const onError = /*#__PURE__*/dual(2, (self, f) => onExitFilter(self, exitFilterCause, f));
/** @internal */
export const onErrorIf = /*#__PURE__*/dual(3, (self, predicate, f) => onExitIf(self, exit => {
  if (exit._tag !== "Failure") {
    return false;
  }
  return predicate(exit.cause);
}, exit => f(exit.cause)));
/** @internal */
export const onErrorFilter = /*#__PURE__*/dual(3, (self, filter, f) => onExit(self, exit => {
  if (exit._tag !== "Failure") {
    return void_;
  }
  const result = filter(exit.cause);
  return Result.isFailure(result) ? void_ : f(result.success, exit.cause);
}));
/** @internal */
export const onInterrupt = /*#__PURE__*/dual(2, (self, finalizer) => onErrorFilter(causeFilterInterruptors, finalizer)(self));
/** @internal */
export const acquireUseRelease = (acquire, use, release) => uninterruptibleMask(restore => flatMap(acquire, a => onExitPrimitive(suspend(() => restore(use(a))), exit => release(a, exit), true)));
/** @internal */
export const acquireDisposable = acquire => acquireRelease(acquire, resource => hasProperty(resource, Symbol.asyncDispose) ? promise(() => resource[Symbol.asyncDispose]()) : sync(() => resource[Symbol.dispose]()));
// ----------------------------------------------------------------------------
// Caching
// ----------------------------------------------------------------------------
/** @internal */
export const cachedInvalidateWithTTL = /*#__PURE__*/dual(2, (self, ttl) => sync(() => makeCachedUnsafe(self, typeof ttl === "function" ? exit => Duration.toMillis(Duration.fromInputUnsafe(ttl(exit))) : constant(Duration.toMillis(Duration.fromInputUnsafe(ttl))))));
const infiniteTTL = /*#__PURE__*/constant(Infinity);
const makeCachedUnsafe = (self, ttlMillis) => {
  let expiresAt = 0;
  let exit;
  let current;
  const join = (fiber, run) => {
    run.awaiters++;
    onExitUnsafe(fiber, () => {
      // Abandon the run once every caller has left, unless it already finished.
      if (--run.awaiters > 0 || current !== run) return;
      // Detach it first so new callers start a fresh run instead of joining
      // one that is being interrupted.
      current = undefined;
      return fiberInterrupt(run.fiber);
    });
    return fiberJoin(run.fiber);
  };
  return [withFiber(fiber => {
    if (current !== undefined) return join(fiber, current);
    if (exit !== undefined && (expiresAt === Infinity || fiber.getRef(ClockRef).currentTimeMillisUnsafe() < expiresAt)) {
      return exit;
    }
    exit = undefined;
    const clock = fiber.getRef(ClockRef);
    const run = {
      fiber: undefined,
      awaiters: 0
    };
    current = run;
    run.fiber = forkUnsafe(fiber, onExitPrimitive(self, exit_ => {
      // An abandoned run must not overwrite or clear a replacement run.
      if (current !== run) return;
      current = undefined;
      // Interruption is abandonment, so it is never cached.
      if (exitHasInterrupts(exit_)) return;
      const duration = ttlMillis(exit_);
      expiresAt = duration === Infinity ? Infinity : clock.currentTimeMillisUnsafe() + duration;
      exit = exit_;
    }), true, true);
    return run.fiber._exit ?? join(fiber, run);
  }), sync(() => {
    exit = undefined;
  })];
};
/** @internal */
export const cachedWithTTL = /*#__PURE__*/dual(2, (self, timeToLive) => map(cachedInvalidateWithTTL(self, timeToLive), tuple => tuple[0]));
/** @internal */
export const cached = self => sync(() => makeCachedUnsafe(self, infiniteTTL)[0]);
// ----------------------------------------------------------------------------
// interruption
// ----------------------------------------------------------------------------
/** @internal */
export const interrupt = /*#__PURE__*/withFiber(fiber => failCause(causeInterrupt(fiber.id)));
/** @internal */
export const uninterruptible = self => withFiber(fiber => {
  if (!fiber.interruptible) return self;
  fiber.interruptible = false;
  fiber._stack.push(setInterruptibleTrue);
  return self;
});
const setInterruptible = /*#__PURE__*/makePrimitive({
  op: "SetInterruptible",
  [contAll](fiber) {
    fiber.interruptible = this[args];
    if (fiber._interruptedCause && fiber.interruptible) {
      return () => failCause(fiber._interruptedCause);
    }
  }
});
const setInterruptibleTrue = /*#__PURE__*/setInterruptible(true);
const setInterruptibleFalse = /*#__PURE__*/setInterruptible(false);
const setFiberInterruptible = fiber => {
  fiber.interruptible = true;
  fiber._stack.push(setInterruptibleFalse);
  if (fiber._interruptedCause) return failCause(fiber._interruptedCause);
};
/**
 * Makes the current fiber uninterruptible for the returned effect without an
 * extra primitive. Call only within `withFiber`.
 *
 * @internal
 */
export const fiberEnterUninterruptibleUnsafe = fiber => {
  const impl = fiber;
  if (!impl.interruptible) return;
  impl.interruptible = false;
  impl._stack.push(setInterruptibleTrue);
};
/**
 * Makes the current fiber interruptible for the returned effect without an
 * extra primitive. Call only within `withFiber` and return any pending
 * interruption it produces.
 *
 * @internal
 */
export const fiberEnterInterruptibleUnsafe = fiber => {
  const impl = fiber;
  if (impl.interruptible) return undefined;
  return setFiberInterruptible(impl);
};
/** @internal */
export const interruptible = self => withFiber(fiber => {
  if (fiber.interruptible) return self;
  return setFiberInterruptible(fiber) ?? self;
});
/** @internal */
export const uninterruptibleMask = f => withFiber(fiber => {
  if (!fiber.interruptible) return f(identity);
  fiber.interruptible = false;
  fiber._stack.push(setInterruptibleTrue);
  return f(interruptible);
});
/** @internal */
export const interruptibleMask = f => withFiber(fiber => {
  if (fiber.interruptible) return f(identity);
  const interrupted = setFiberInterruptible(fiber);
  const effect = f(uninterruptible);
  return interrupted ?? effect;
});
/** @internal */
export const abortSignal = /*#__PURE__*/map(/*#__PURE__*/acquireRelease(/*#__PURE__*/sync(() => new AbortController()), controller => sync(() => controller.abort())), _ => _.signal);
// ========================================================================
// collecting & elements
// ========================================================================
/** @internal */
export const all = (arg, options) => {
  if (isIterable(arg)) {
    return options?.mode === "result" ? forEach(arg, result, options) : forEach(arg, identity, options);
  } else if (options?.discard) {
    return options.mode === "result" ? forEach(Object.values(arg), result, options) : forEach(Object.values(arg), identity, options);
  }
  return suspend(() => {
    const out = {};
    return as(forEach(Object.entries(arg), ([key, effect]) => map(options?.mode === "result" ? result(effect) : effect, value => {
      InternalRecord.assignProperty(out, key, value);
    }), {
      discard: true,
      concurrency: options?.concurrency
    }), out);
  });
};
/** @internal */
export const partition = /*#__PURE__*/dual(args => isIterable(args[0]) && !isEffect(args[0]), (elements, f, options) => map(forEach(elements, (a, i) => result(f(a, i)), options), results => Arr.partition(results, identity)));
/** @internal */
export const reduce = /*#__PURE__*/dual(3, (elements, zero, f) => {
  const arr = Arr.fromIterable(elements);
  if (arr.length === 0) return sync(zero);
  return suspend(() => {
    let index = 0;
    let state = zero();
    return map(whileLoop({
      while: () => index < arr.length,
      body: () => f(state, arr[index], index),
      step(next) {
        state = next;
        index++;
      }
    }), () => state);
  });
});
/** @internal */
export const validate = /*#__PURE__*/dual(args => isIterable(args[0]) && !isEffect(args[0]), (elements, f, options) => flatMap(partition(elements, f, {
  concurrency: options?.concurrency
}), ([passes, fails]) => {
  if (Arr.isArrayNonEmpty(fails)) {
    return fail(fails);
  }
  return options?.discard ? void_ : succeed(passes);
}));
/** @internal */
export const findFirst = /*#__PURE__*/dual(args => isIterable(args[0]) && !isEffect(args[0]), (elements, predicate) => suspend(() => {
  const iterator = elements[Symbol.iterator]();
  const next = iterator.next();
  if (!next.done) {
    return findFirstLoop(iterator, 0, predicate, next.value);
  }
  return succeed(Option.none());
}));
const findFirstLoop = (iterator, index, predicate, value) => flatMap(predicate(value, index), keep => {
  if (keep) {
    return succeed(Option.some(value));
  }
  const next = iterator.next();
  if (!next.done) {
    return findFirstLoop(iterator, index + 1, predicate, next.value);
  }
  return succeed(Option.none());
});
/** @internal */
export const findFirstFilter = /*#__PURE__*/dual(args => isIterable(args[0]) && !isEffect(args[0]), (elements, filter) => suspend(() => {
  const iterator = elements[Symbol.iterator]();
  const next = iterator.next();
  if (!next.done) {
    return findFirstFilterLoop(iterator, 0, filter, next.value);
  }
  return succeed(Option.none());
}));
const findFirstFilterLoop = (iterator, index, filter, value) => flatMap(filter(value, index), result => {
  if (Result.isSuccess(result)) {
    return succeed(Option.some(result.success));
  }
  const next = iterator.next();
  if (!next.done) {
    return findFirstFilterLoop(iterator, index + 1, filter, next.value);
  }
  return succeed(Option.none());
});
/** @internal */
export const whileLoop = /*#__PURE__*/makePrimitive({
  op: "While",
  [contA](value, fiber) {
    this[args].step(value);
    if (this[args].while()) {
      fiber._stack.push(this);
      return this[args].body();
    }
    return exitVoid;
  },
  [evaluate](fiber) {
    if (this[args].while()) {
      fiber._stack.push(this);
      return this[args].body();
    }
    return exitVoid;
  }
});
/** @internal */
export const forEach = /*#__PURE__*/dual(args => typeof args[1] === "function", (iterable, f, options) => suspend(() => {
  const concurrency = resolveConcurrency(options?.concurrency);
  if (concurrency === 1) {
    return forEachSequential(iterable, f, options);
  }
  const items = Arr.fromIterable(iterable);
  let length = items.length;
  if (length === 0) {
    return options?.discard ? void_ : succeed([]);
  }
  const out = options?.discard ? undefined : new Array(length);
  const eff = forEachConcurrent({
    f,
    out
  }, items, {
    concurrency
  });
  return eff ? as(eff, out) : succeed(out);
}));
/** @internal */
export const head = self => flatMap(self, elements => {
  const result = elements[Symbol.iterator]().next();
  return result.done ? fail(new NoSuchElementError()) : succeed(result.value);
});
const forEachSequential = (iterable, f, options) => suspend(() => {
  const out = options?.discard ? undefined : [];
  const iterator = iterable[Symbol.iterator]();
  let state = iterator.next();
  let index = 0;
  return as(whileLoop({
    while: () => !state.done,
    body: () => f(state.value, index++),
    step: b => {
      if (out) out.push(b);
      state = iterator.next();
    }
  }), out);
});
/** @internal */
export const resolveConcurrency = concurrency => concurrency === "unbounded" ? Number.POSITIVE_INFINITY : Math.max(1, concurrency ?? 1);
/** @internal */
export const iterateEager = () => options => {
  const onItem = options.onItem;
  const step = options.step;
  const resumeSequential = (state, items, index, end, effect) => flatMap(exit(effect), itemExit => step(state, items[index], itemExit, index) ?? runSequential(state, items, index + 1, end) ?? void_);
  const runSequential = (state, items, index = 0, end = items.length) => {
    for (; index < end; index++) {
      const item = items[index];
      const effect = onItem(state, item, index);
      if (!effectIsExit(effect)) {
        return resumeSequential(state, items, index, end, effect);
      }
      const terminal = step(state, item, effect, index);
      if (terminal) return terminal._tag === "Failure" ? terminal : undefined;
    }
  };
  return runSequential;
};
const iterateConcurrentImpl = options => {
  const onItem = options.onItem;
  const step = options.step;
  return (state, items, opts) => {
    let index = 0;
    const end = opts.end ?? items.length;
    const concurrency = opts.concurrency;
    let done = false;
    let parentFiber;
    let fibers;
    let resume;
    let terminal;
    let effect;
    const failDefect = error => {
      const defect = exitDie(error);
      terminal = defect;
      done = true;
      return fibers && fibers.size > 0 ? flatMap(uninterruptible(fiberInterruptAll(Array.from(fibers))), () => terminal ?? defect) : defect;
    };
    const go = () => {
      let paused = false;
      for (; !terminal && index < end; index++) {
        const item = items[index];
        const eff = effect ?? onItem(state, item, index);
        if (effectIsExit(eff)) {
          terminal = step(state, item, eff, index);
          if (terminal) break;
        } else if (!parentFiber) {
          return callback(cb => {
            parentFiber = getCurrentFiber();
            fibers = new Set();
            effect = eff;
            resume = cb;
            let result;
            try {
              result = go();
            } catch (error) {
              return cb(failDefect(error));
            }
            if (result) return cb(result);
            return suspend(() => {
              terminal ??= exitVoid;
              return flatMap(fibers ? fiberInterruptAll(fibers) : void_, () => terminal?._tag === "Failure" ? terminal : void_);
            });
          });
        } else {
          // Clear the effect cached before the parent fiber was available.
          effect = undefined;
          const fiber = forkUnsafe(parentFiber, eff, true, true, "inherit");
          if (fiber._exit) {
            terminal = step(state, item, fiber._exit, index);
            if (terminal) break;
            continue;
          }
          fibers.add(fiber);
          const currentIndex = index;
          fiber.addObserver(exit => {
            fibers.delete(fiber);
            try {
              if (terminal) {
                if (exit._tag === "Failure") {
                  const reasons = exit.cause.reasons.filter(reason => reason._tag !== "Interrupt");
                  if (reasons.length > 0) {
                    const cause = causeFromReasons(reasons);
                    terminal = exitFailCause(terminal._tag === "Failure" ? causeCombine(terminal.cause, cause) : cause);
                  }
                }
              } else {
                const result = step(state, item, exit, currentIndex);
                if (result) {
                  terminal = result;
                  go();
                }
              }
              if (paused) {
                const eff = go();
                if (eff) resume(eff);
              } else if (done && fibers.size === 0) {
                resume(terminal ?? void_);
              }
            } catch (error) {
              resume(failDefect(error));
            }
          });
          if (fibers.size < concurrency) continue;
          paused = true;
          index++;
          return;
        }
      }
      done = true;
      if (terminal) {
        if (fibers && fibers.size > 0) {
          const annotations = fiberStackAnnotations(parentFiber);
          fibers.forEach(f => f.interruptUnsafe(parentFiber.id, annotations));
          return;
        }
        if (resume || terminal._tag === "Failure") {
          return terminal;
        }
      } else if (resume) {
        if (!fibers) {
          return exitVoid;
        } else if (fibers.size === 0) {
          resume(void_);
        }
      }
    };
    return go();
  };
};
/** @internal */
export const iterateConcurrent = () => options => iterateConcurrentImpl(options);
const forEachConcurrent = /*#__PURE__*/iterateConcurrentImpl({
  onItem(state, item, index) {
    return state.f(item, index);
  },
  step(state, _, exit, index) {
    if (exit._tag === "Failure") return exit;else if (state.out) {
      state.out[index] = exit.value;
    }
  }
});
/** @internal */
export const filterOrElse = /*#__PURE__*/dual(3, (self, predicate, orElse) => flatMap(self, a => predicate(a) ? succeed(a) : orElse(a)));
/** @internal */
export const filterMapOrElse = /*#__PURE__*/dual(3, (self, filter, orElse) => flatMap(self, a => {
  const result = filter(a);
  return Result.isFailure(result) ? orElse(result.failure) : succeed(result.success);
}));
/** @internal */
export const filterMapOrFail = /*#__PURE__*/dual(args => isEffect(args[0]), (self, filter, orFailWith) => filterMapOrElse(self, filter, orFailWith ? x => fail(orFailWith(x)) : () => fail(new NoSuchElementError())));
/** @internal */
export const filter = /*#__PURE__*/dual(args => isIterable(args[0]) && !isEffect(args[0]), (elements, predicate, options) => suspend(() => {
  const out = [];
  return as(forEach(elements, (a, i) => {
    const result = predicate(a, i);
    if (typeof result === "boolean") {
      if (result) out.push(a);
      return void_;
    }
    return map(result, keep => {
      if (keep) {
        out.push(a);
      }
    });
  }, {
    discard: true,
    concurrency: options?.concurrency
  }), out);
}));
/** @internal */
export const filterMap = /*#__PURE__*/dual(args => isIterable(args[0]) && !isEffect(args[0]), (elements, filter) => suspend(() => {
  const out = [];
  for (const a of elements) {
    const result = filter(a);
    if (Result.isSuccess(result)) {
      out.push(result.success);
    }
  }
  return succeed(out);
}));
/** @internal */
export const filterMapEffect = /*#__PURE__*/dual(args => isIterable(args[0]) && !isEffect(args[0]), (elements, filter, options) => suspend(() => {
  const out = [];
  return as(forEach(elements, a => map(filter(a), result => {
    if (Result.isSuccess(result)) {
      out.push(result.success);
    }
  }), {
    discard: true,
    concurrency: options?.concurrency
  }), out);
}));
// ----------------------------------------------------------------------------
// do notation
// ----------------------------------------------------------------------------
/** @internal */
export const Do = /*#__PURE__*/succeed({});
/** @internal */
export const bindTo = /*#__PURE__*/doNotation.bindTo(map);
/** @internal */
export const bind = /*#__PURE__*/doNotation.bind(map, flatMap);
/** @internal */
const let_ = /*#__PURE__*/doNotation.let_(map);
/** @internal */
export { let_ as let };
// ----------------------------------------------------------------------------
// fibers & forking
// ----------------------------------------------------------------------------
/** @internal */
export const forkChild = /*#__PURE__*/dual(args => isEffect(args[0]), (self, options) => withFiber(fiber => {
  interruptChildrenPatch();
  return succeed(forkUnsafe(fiber, self, options?.startImmediately, false, options?.uninterruptible ?? false));
}));
/** @internal */
export const forkUnsafe = (parent, effect, immediate = false, daemon = false, uninterruptible = false) => {
  const parentRuntime = parent;
  const interruptible = uninterruptible === "inherit" ? parentRuntime.interruptible : !uninterruptible;
  const child = new FiberImpl(parentRuntime.context, interruptible);
  if (immediate) {
    child.evaluate(effect);
  } else {
    // Preserve the fork context rather than the dispatcher's context.
    child._asyncContext = captureAsyncContext();
    parentRuntime.currentDispatcher.scheduleTask(() => child.evaluate(effect), 0);
  }
  if (!daemon && !child._exit) {
    parentRuntime.children().add(child);
    child._parent = parentRuntime;
  }
  return child;
};
/** @internal */
export const forkDetach = /*#__PURE__*/dual(args => isEffect(args[0]), (self, options) => withFiber(fiber => succeed(forkUnsafe(fiber, self, options?.startImmediately, true, options?.uninterruptible))));
/** @internal */
export const awaitAllChildren = self => withFiber(fiber => {
  const initialChildren = fiber._children && new Set(fiber._children);
  const isInterruptible = fiber.interruptible;
  return onExitPrimitive(self, _ => {
    let children = fiber._children;
    if (children === undefined || children.size === 0) {
      return void_;
    } else if (initialChildren) {
      children = Iterable.filter(children, child => !initialChildren.has(child));
    }
    const awaitChildren = asVoid(fiberAwaitAll(children));
    return isInterruptible ? interruptible(awaitChildren) : awaitChildren;
  });
});
/** @internal */
export const forkIn = /*#__PURE__*/dual(args => isEffect(args[0]), (self, scope, options) => withFiber(parent => {
  const fiber = forkUnsafe(parent, self, options?.startImmediately, true, options?.uninterruptible);
  if (!fiber._exit) {
    if (scope.state._tag !== "Closed") {
      const key = {};
      const finalizer = () => withFiberId(interruptor => interruptor === fiber.id ? void_ : fiberInterrupt(fiber));
      scopeAddFinalizerUnsafe(scope, key, finalizer);
      fiber.addObserver(() => scopeRemoveFinalizerUnsafe(scope, key));
    } else {
      fiber.interruptUnsafe(parent.id, fiberStackAnnotations(parent));
    }
  }
  return succeed(fiber);
}));
/** @internal */
export const forkScoped = /*#__PURE__*/dual(args => isEffect(args[0]), (self, options) => flatMap(scope, scope => forkIn(self, scope, options)));
// ----------------------------------------------------------------------------
// execution
// ----------------------------------------------------------------------------
/** @internal */
export const runForkWith = context => (effect, options) => {
  const fiber = new FiberImpl(options?.scheduler ? Context.add(context, Scheduler.Scheduler, options.scheduler) : context, options?.uninterruptible !== true);
  fiber.evaluate(effect);
  if (fiber._exit) return fiber;
  if (options?.signal) {
    if (options.signal.aborted) {
      fiber.interruptUnsafe();
    } else {
      const abort = () => fiber.interruptUnsafe();
      options.signal.addEventListener("abort", abort, {
        once: true
      });
      fiber.addObserver(() => options.signal.removeEventListener("abort", abort));
    }
  }
  if (options?.onFiberStart) {
    options.onFiberStart(fiber);
  }
  return fiber;
};
/** @internal */
export const fiberRunIn = /*#__PURE__*/dual(2, (self, scope) => {
  if (self._exit) {
    return self;
  } else if (scope.state._tag === "Closed") {
    self.interruptUnsafe(self.id);
    return self;
  }
  const key = {};
  scopeAddFinalizerUnsafe(scope, key, () => fiberInterrupt(self));
  self.addObserver(() => scopeRemoveFinalizerUnsafe(scope, key));
  return self;
});
/** @internal */
export const runFork = /*#__PURE__*/runForkWith(/*#__PURE__*/Context.empty());
/** @internal */
export const runCallbackWith = context => {
  const runFork = runForkWith(context);
  return (effect, options) => {
    const fiber = runFork(effect, options);
    if (options?.onExit) {
      fiber.addObserver(options.onExit);
    }
    return interruptor => {
      return fiber.interruptUnsafe(interruptor);
    };
  };
};
/** @internal */
export const runCallback = /*#__PURE__*/runCallbackWith(/*#__PURE__*/Context.empty());
/** @internal */
export const runPromiseExitWith = context => {
  const runFork = runForkWith(context);
  return (effect, options) => {
    const fiber = runFork(effect, options);
    return new Promise(resolve => {
      fiber.addObserver(exit => resolve(exit));
    });
  };
};
/** @internal */
export const runPromiseExit = /*#__PURE__*/runPromiseExitWith(/*#__PURE__*/Context.empty());
/** @internal */
export const runPromiseWith = context => {
  const runPromiseExit = runPromiseExitWith(context);
  return (effect, options) => runPromiseExit(effect, options).then(exit => {
    if (exit._tag === "Failure") {
      throw causeSquash(exit.cause);
    }
    return exit.value;
  });
};
/** @internal */
export const runPromise = /*#__PURE__*/runPromiseWith(/*#__PURE__*/Context.empty());
/** @internal */
export const runSyncExitWith = context => {
  const runFork = runForkWith(context);
  return effect => {
    if (effectIsExit(effect)) return effect;
    const scheduler = new Scheduler.MixedScheduler("sync");
    const fiber = runFork(effect, {
      scheduler
    });
    fiber._dispatcher?.flush();
    return fiber._exit ?? exitDie(new AsyncFiberError(fiber));
  };
};
/** @internal */
export const runSyncExit = /*#__PURE__*/runSyncExitWith(/*#__PURE__*/Context.empty());
/** @internal */
export const runSyncWith = context => {
  const runSyncExit = runSyncExitWith(context);
  return effect => {
    const exit = runSyncExit(effect);
    if (exit._tag === "Failure") throw causeSquash(exit.cause);
    return exit.value;
  };
};
/** @internal */
export const runSync = /*#__PURE__*/runSyncWith(/*#__PURE__*/Context.empty());
const succeedTrue = /*#__PURE__*/succeed(true);
const succeedFalse = /*#__PURE__*/succeed(false);
class Latch {
  waiters = [];
  scheduled = undefined;
  _isOpen;
  constructor(isOpen) {
    this._isOpen = isOpen;
  }
  scheduleUnsafe(fiber) {
    if (this.waiters.length === 0) {
      return succeedTrue;
    }
    if (this.scheduled === undefined) {
      this.scheduled = this.waiters;
      fiber.currentDispatcher.scheduleTask(this.flushScheduled, 0);
    } else {
      for (let i = 0; i < this.waiters.length; i++) {
        this.scheduled.push(this.waiters[i]);
      }
    }
    this.waiters = [];
    return succeedTrue;
  }
  flushScheduled = () => {
    if (this.scheduled === undefined) return;
    const waiters = this.scheduled;
    this.scheduled = undefined;
    for (let i = 0; i < waiters.length; i++) {
      waiters[i](exitVoid);
    }
  };
  flushWaiters() {
    // swap both arrays out before any resume runs: a resumed waiter can
    // reentrantly close the latch and register new waiters, which must not
    // be drained by this flush
    const waiters = this.waiters;
    this.waiters = [];
    this.flushScheduled();
    for (let i = 0; i < waiters.length; i++) {
      waiters[i](exitVoid);
    }
  }
  open = /*#__PURE__*/withFiber(fiber => {
    if (this._isOpen) return succeedFalse;
    this._isOpen = true;
    return this.scheduleUnsafe(fiber);
  });
  release = /*#__PURE__*/withFiber(fiber => this._isOpen ? succeedFalse : this.scheduleUnsafe(fiber));
  openUnsafe() {
    if (this._isOpen) return false;
    this._isOpen = true;
    this.flushWaiters();
    return true;
  }
  await = /*#__PURE__*/callback(resume => {
    if (this._isOpen) {
      return resume(void_);
    }
    this.waiters.push(resume);
    return sync(() => {
      let index = this.waiters.indexOf(resume);
      if (index !== -1) {
        this.waiters.splice(index, 1);
      } else if (this.scheduled !== undefined) {
        index = this.scheduled.indexOf(resume);
        if (index !== -1) {
          this.scheduled.splice(index, 1);
        }
      }
    });
  });
  closeUnsafe() {
    if (!this._isOpen) return false;
    this._isOpen = false;
    return true;
  }
  close = /*#__PURE__*/sync(() => this.closeUnsafe());
  whenOpen = self => flatMap(this.await, () => self);
  isOpen() {
    return this._isOpen;
  }
}
/** @internal */
export const makeLatchUnsafe = open => new Latch(open ?? false);
/** @internal */
export const makeLatch = open => sync(() => makeLatchUnsafe(open));
// ----------------------------------------------------------------------------
// Tracer
// ----------------------------------------------------------------------------
/** @internal */
export const tracer = /*#__PURE__*/withFiber(fiber => succeed(fiber.getRef(Tracer.Tracer)));
/** @internal */
export const withTracer = /*#__PURE__*/dual(2, (effect, tracer) => provideService(effect, Tracer.Tracer, tracer));
/** @internal */
export const withTracerEnabled = /*#__PURE__*/provideService(TracerEnabled);
/** @internal */
export const withTracerTiming = /*#__PURE__*/provideService(TracerTimingEnabled);
const bigint0 = /*#__PURE__*/BigInt(0);
const NoopSpanProto = {
  _tag: "Span",
  spanId: "noop",
  traceId: "noop",
  sampled: false,
  status: {
    _tag: "Ended",
    startTime: bigint0,
    endTime: bigint0,
    exit: exitVoid
  },
  attributes: /*#__PURE__*/new Map(),
  links: [],
  kind: "internal",
  attribute() {},
  event() {},
  end() {},
  addLinks() {}
};
/** @internal */
export const noopSpan = options => Object.assign(Object.create(NoopSpanProto), options);
const filterDisablePropagation = span => {
  if (!span) return Option.none();
  return Context.get(span.annotations, Tracer.DisablePropagation) ? span._tag === "Span" ? filterDisablePropagation(Option.getOrUndefined(span.parent)) : Option.none() : Option.some(span);
};
/** @internal */
export const makeSpanUnsafe = (fiber, name, options) => {
  const disablePropagation = !fiber.cache.tracerEnabled || options?.annotations && Context.get(options.annotations, Tracer.DisablePropagation);
  const parent = options?.parent !== undefined ? Option.some(options.parent) : options?.root ? Option.none() : filterDisablePropagation(fiber.cache.span);
  let span;
  if (disablePropagation) {
    span = noopSpan({
      name,
      parent,
      annotations: Context.add(options?.annotations ?? Context.empty(), Tracer.DisablePropagation, true)
    });
  } else {
    // The cache stores only explicit tracer overrides; absent references use the default.
    const tracer = fiber.cache.tracer ?? Tracer.nativeTracer;
    const clock = fiber.getRef(ClockRef);
    const timingEnabled = fiber.getRef(TracerTimingEnabled);
    const annotationsFromEnv = fiber.getRef(TracerSpanAnnotations);
    const linksFromEnv = fiber.getRef(TracerSpanLinks);
    const level = options?.level ?? fiber.getRef(Tracer.CurrentTraceLevel);
    const links = options?.links !== undefined ? [...linksFromEnv, ...options.links] : linksFromEnv.length === 0 ? [] : linksFromEnv.slice();
    span = tracer.span({
      name,
      parent,
      annotations: options?.annotations ?? Context.empty(),
      links,
      startTime: timingEnabled ? clock.currentTimeNanosUnsafe() : bigint0,
      kind: options?.kind ?? "internal",
      root: options?.root ?? Option.isNone(parent),
      sampled: options?.sampled ?? (Option.isSome(parent) && parent.value.sampled === false ? false : !isLogLevelGreaterThan(fiber.getRef(Tracer.MinimumTraceLevel), level))
    });
    for (const key in annotationsFromEnv) {
      span.attribute(key, annotationsFromEnv[key]);
    }
    if (options?.attributes !== undefined) {
      for (const key in options.attributes) {
        span.attribute(key, options.attributes[key]);
      }
    }
  }
  return span;
};
/** @internal */
export const makeSpan = (name, options) => withFiber(fiber => succeed(makeSpanUnsafe(fiber, name, options)));
/** @internal */
export const makeSpanScoped = (name, options) => uninterruptible(withFiber(fiber => {
  const scope = Context.getUnsafe(fiber.context, scopeTag);
  const span = makeSpanUnsafe(fiber, name, options ?? {});
  const clock = fiber.getRef(ClockRef);
  const timingEnabled = fiber.getRef(TracerTimingEnabled);
  return as(scopeAddFinalizerExit(scope, exit => endSpan(span, exit, clock, timingEnabled)), span);
}));
/** @internal */
export const withSpanScoped = function () {
  const dataFirst = typeof arguments[0] !== "string";
  const name = dataFirst ? arguments[1] : arguments[0];
  const options = addSpanStackTrace(dataFirst ? arguments[2] : arguments[1]);
  if (dataFirst) {
    const self = arguments[0];
    return flatMap(makeSpanScoped(name, options), span => withParentSpan(self, span, options));
  }
  return self => flatMap(makeSpanScoped(name, options), span => withParentSpan(self, span, options));
};
const provideSpanStackFrame = (name, stack) => {
  stack = typeof stack === "function" ? stack : constUndefined;
  return updateService(CurrentStackFrame, parent => ({
    name,
    stack,
    parent
  }));
};
/** @internal */
export const spanAnnotations = TracerSpanAnnotations;
/** @internal */
export const spanLinks = TracerSpanLinks;
/** @internal */
export const linkSpans = /*#__PURE__*/dual(args => isEffect(args[0]), (self, span, attributes = {}) => {
  const spans = Array.isArray(span) ? span : [span];
  const links = spans.map(span => ({
    span,
    attributes
  }));
  return updateService(self, TracerSpanLinks, current => [...current, ...links]);
});
/** @internal */
export const endSpan = (span, exit, clock, timingEnabled) => sync(() => {
  if (span.status._tag === "Ended") return;
  span.end(timingEnabled ? clock.currentTimeNanosUnsafe() : bigint0, exit);
});
/** @internal */
export const useSpan = (name, ...args) => {
  const options = args.length === 1 ? undefined : args[0];
  const evaluate = args[args.length - 1];
  return withFiber(fiber => {
    const span = makeSpanUnsafe(fiber, name, options);
    const clock = fiber.getRef(ClockRef);
    const timingEnabled = fiber.getRef(TracerTimingEnabled);
    onExitUnsafe(fiber, exit => endSpan(span, exit, clock, timingEnabled));
    return evaluate(span);
  });
};
const provideParentSpan = /*#__PURE__*/provideService(Tracer.ParentSpan);
/** @internal */
export const withParentSpan = function () {
  const dataFirst = isEffect(arguments[0]);
  const span = dataFirst ? arguments[1] : arguments[0];
  let options = dataFirst ? arguments[2] : arguments[1];
  let provideStackFrame = identity;
  if (span._tag === "Span") {
    options = addSpanStackTrace(options);
    provideStackFrame = provideSpanStackFrame(span.name, options?.captureStackTrace);
  }
  if (dataFirst) {
    return provideParentSpan(provideStackFrame(arguments[0]), span);
  }
  return self => provideParentSpan(provideStackFrame(self), span);
};
/** @internal */
export const withSpan = function () {
  const dataFirst = typeof arguments[0] !== "string";
  const name = dataFirst ? arguments[1] : arguments[0];
  const traceOptions = addSpanStackTrace(arguments[2]);
  if (dataFirst) {
    const self = arguments[0];
    return useSpan(name, arguments[2], span => withParentSpan(self, span, traceOptions));
  }
  const fnArg = typeof arguments[1] === "function" ? arguments[1] : undefined;
  const options = fnArg ? undefined : arguments[1];
  return (self, ...args) => useSpan(name, fnArg ? fnArg(...args) : options, span => withParentSpan(self, span, traceOptions));
};
/** @internal */
export const annotateSpans = /*#__PURE__*/dual(args => isEffect(args[0]), (effect, ...args) => updateService(effect, TracerSpanAnnotations, annotations => {
  const newAnnotations = args.length === 1 ? {
    ...annotations,
    ...args[0]
  } : {
    ...annotations
  };
  if (args.length === 1) {
    return newAnnotations;
  } else {
    InternalRecord.assignProperty(newAnnotations, args[0], args[1]);
  }
  return newAnnotations;
}));
/** @internal */
export const annotateCurrentSpan = (...args) => withFiber(fiber => {
  const span = fiber.currentSpanLocal;
  if (span) {
    if (args.length === 1) {
      for (const [key, value] of Object.entries(args[0])) {
        span.attribute(key, value);
      }
    } else {
      span.attribute(args[0], args[1]);
    }
  }
  return void_;
});
/** @internal */
export const currentSpan = /*#__PURE__*/withFiber(fiber => {
  const span = fiber.currentSpanLocal;
  return span ? succeed(span) : fail(new NoSuchElementError());
});
/** @internal */
export const currentParentSpan = /*#__PURE__*/serviceOptional(Tracer.ParentSpan);
// ----------------------------------------------------------------------------
// Clock
// ----------------------------------------------------------------------------
/** @internal */
export const ClockRef = /*#__PURE__*/Context.Reference("effect/Clock", {
  defaultValue: () => new ClockImpl()
});
const MAX_TIMER_MILLIS = 2 ** 31 - 1;
class ClockImpl {
  currentTimeMillisUnsafe() {
    return Date.now();
  }
  currentTimeMillis = /*#__PURE__*/sync(() => this.currentTimeMillisUnsafe());
  currentTimeNanosUnsafe() {
    return wallTimeNanos();
  }
  currentTimeNanos = /*#__PURE__*/sync(() => this.currentTimeNanosUnsafe());
  monotonicTimeNanosUnsafe() {
    return monotonicNowNanos();
  }
  monotonicTimeNanos = /*#__PURE__*/sync(() => this.monotonicTimeNanosUnsafe());
  sleep(duration) {
    return this.sleepMillis(Duration.toMillis(duration));
  }
  sleepMillis(millis) {
    if (millis <= 0) return yieldNow;else if (!Number.isFinite(millis)) return never;
    return callback(resume => {
      const continuation = millis > MAX_TIMER_MILLIS ? this.sleepMillis(millis - MAX_TIMER_MILLIS) : void_;
      const handle = setTimeout(() => resume(continuation), Math.min(millis, MAX_TIMER_MILLIS));
      return sync(() => clearTimeout(handle));
    });
  }
}
const nanosPerMilli = /*#__PURE__*/BigInt(1_000_000);
const monotonicNowNanos = /*#__PURE__*/function () {
  const processHrtime = globalThis.process?.hrtime;
  if (typeof processHrtime?.bigint === "function") {
    return () => processHrtime.bigint();
  }
  if (typeof performance !== "undefined" && typeof performance.now === "function") {
    return () => BigInt(Math.round(performance.now() * 1_000_000));
  }
  let previous = /*#__PURE__*/BigInt(0);
  return () => {
    const current = BigInt(Date.now()) * nanosPerMilli;
    if (current > previous) {
      previous = current;
    }
    return previous;
  };
}();
const wallTimeNanos = /*#__PURE__*/function () {
  const reanchorThresholdNanos = /*#__PURE__*/BigInt(1_000_000_000);
  let origin;
  return () => {
    const monotonic = monotonicNowNanos();
    const wall = BigInt(Date.now()) * nanosPerMilli;
    if (origin === undefined) {
      origin = wall - monotonic;
    } else {
      const projected = origin + monotonic;
      const skew = wall > projected ? wall - projected : projected - wall;
      if (skew > reanchorThresholdNanos) {
        origin = wall - monotonic;
      }
    }
    return origin + monotonic;
  };
}();
/** @internal */
export const clockWith = f => withFiber(fiber => f(fiber.getRef(ClockRef)));
/** @internal */
export const sleep = duration => clockWith(clock => clock.sleep(Duration.fromInputUnsafe(duration)));
/** @internal */
export const currentTimeMillis = /*#__PURE__*/clockWith(clock => clock.currentTimeMillis);
/** @internal */
export const currentTimeNanos = /*#__PURE__*/clockWith(clock => clock.currentTimeNanos);
/** @internal */
export const monotonicTimeNanos = /*#__PURE__*/clockWith(clock => clock.monotonicTimeNanos);
// ----------------------------------------------------------------------------
// Errors
// ----------------------------------------------------------------------------
/** @internal */
export const TimeoutErrorTypeId = "~effect/Cause/TimeoutError";
/** @internal */
export const isTimeoutError = u => hasProperty(u, TimeoutErrorTypeId);
/** @internal */
export class TimeoutError extends /*#__PURE__*/TaggedError("TimeoutError") {
  [TimeoutErrorTypeId] = TimeoutErrorTypeId;
  constructor(message) {
    super({
      message
    });
  }
}
/** @internal */
export const IllegalArgumentErrorTypeId = "~effect/Cause/IllegalArgumentError";
/** @internal */
export const isIllegalArgumentError = u => hasProperty(u, IllegalArgumentErrorTypeId);
/** @internal */
export class IllegalArgumentError extends /*#__PURE__*/TaggedError("IllegalArgumentError") {
  [IllegalArgumentErrorTypeId] = IllegalArgumentErrorTypeId;
  constructor(message) {
    super({
      message
    });
  }
}
/** @internal */
export const ExceededCapacityErrorTypeId = "~effect/Cause/ExceededCapacityError";
/** @internal */
export const isExceededCapacityError = u => hasProperty(u, ExceededCapacityErrorTypeId);
/** @internal */
export class ExceededCapacityError extends /*#__PURE__*/TaggedError("ExceededCapacityError") {
  [ExceededCapacityErrorTypeId] = ExceededCapacityErrorTypeId;
  constructor(message) {
    super({
      message
    });
  }
}
/** @internal */
export const AsyncFiberErrorTypeId = "~effect/Cause/AsyncFiberError";
/** @internal */
export const isAsyncFiberError = u => hasProperty(u, AsyncFiberErrorTypeId);
/** @internal */
export class AsyncFiberError extends /*#__PURE__*/TaggedError("AsyncFiberError") {
  [AsyncFiberErrorTypeId] = AsyncFiberErrorTypeId;
  constructor(fiber) {
    super({
      message: "An asynchronous Effect was executed with Effect.runSync",
      fiber
    });
  }
}
/** @internal */
export const UnknownErrorTypeId = "~effect/Cause/UnknownError";
/** @internal */
export const isUnknownError = u => hasProperty(u, UnknownErrorTypeId);
/** @internal */
export class UnknownError extends /*#__PURE__*/TaggedError("UnknownError") {
  [UnknownErrorTypeId] = UnknownErrorTypeId;
  constructor(cause, message) {
    super({
      message,
      cause
    });
  }
}
// ----------------------------------------------------------------------------
// Console
// ----------------------------------------------------------------------------
/** @internal */
export const ConsoleRef = /*#__PURE__*/Context.Reference("effect/Console", {
  defaultValue: () => globalThis.console
});
// ----------------------------------------------------------------------------
// LogLevel
// ----------------------------------------------------------------------------
/** @internal */
export const logLevelToOrder = level => {
  switch (level) {
    case "All":
      return Number.MIN_SAFE_INTEGER;
    case "Fatal":
      return 50_000;
    case "Error":
      return 40_000;
    case "Warn":
      return 30_000;
    case "Info":
      return 20_000;
    case "Debug":
      return 10_000;
    case "Trace":
      return 0;
    case "None":
      return Number.MAX_SAFE_INTEGER;
  }
};
/** @internal */
export const LogLevelOrder = /*#__PURE__*/Order.mapInput(Order.Number, logLevelToOrder);
/** @internal */
export const isLogLevelGreaterThan = /*#__PURE__*/Order.isGreaterThan(LogLevelOrder);
// ----------------------------------------------------------------------------
// Logger
// ----------------------------------------------------------------------------
/** @internal */
export const CurrentLoggers = /*#__PURE__*/Context.Reference("effect/Logger/CurrentLoggers", {
  defaultValue: () => new Set([defaultLogger, tracerLogger])
});
/** @internal */
export const LogToStderr = /*#__PURE__*/Context.Reference("effect/Logger/LogToStderr", {
  defaultValue: constFalse
});
/** @internal */
export const annotateLogsScoped = function () {
  const entries = typeof arguments[0] === "string" ? [[arguments[0], arguments[1]]] : Object.entries(arguments[0]);
  return uninterruptible(withFiber(fiber => {
    const prev = fiber.getRef(CurrentLogAnnotations);
    const next = {
      ...prev
    };
    for (let i = 0; i < entries.length; i++) {
      const [key, value] = entries[i];
      InternalRecord.assignProperty(next, key, value);
    }
    fiber.setContext(Context.add(fiber.context, CurrentLogAnnotations, next));
    return scopeAddFinalizerExit(Context.getUnsafe(fiber.context, scopeTag), _ => {
      const current = fiber.getRef(CurrentLogAnnotations);
      const next = {
        ...current
      };
      for (let i = 0; i < entries.length; i++) {
        const [key, value] = entries[i];
        if (current[key] !== value && !Object.is(current[key], value)) continue;
        if (Object.hasOwn(prev, key)) {
          InternalRecord.assignProperty(next, key, prev[key]);
        } else {
          delete next[key];
        }
      }
      fiber.setContext(Context.add(fiber.context, CurrentLogAnnotations, next));
      return void_;
    });
  }));
};
/** @internal */
export const LoggerTypeId = "~effect/Logger";
const LoggerProto = {
  [LoggerTypeId]: {
    _Message: identity,
    _Output: identity
  },
  pipe() {
    return pipeArguments(this, arguments);
  }
};
/** @internal */
export const loggerMake = log => {
  const self = Object.create(LoggerProto);
  self.log = log;
  return self;
};
/**
 * Sanitize a given string by replacing spaces, equal signs, and double quotes
 * with underscores.
 *
 * @internal
 */
export const formatLabel = key => key.replace(/[\s="]/g, "_");
/**
 * Formats a log span into a `<label>=<value>ms` string.
 *
 * @internal
 */
export const formatLogSpan = (self, now) => {
  const label = formatLabel(self[0]);
  return `${label}=${now - self[1]}ms`;
};
/** @internal */
export const structuredMessage = u => {
  switch (typeof u) {
    case "function":
    case "symbol":
      {
        return String(u);
      }
    default:
      {
        return toJson(u);
      }
  }
};
/** @internal */
export const logWithLevel = level => (...message) => {
  let cause = undefined;
  for (let i = 0, len = message.length; i < len; i++) {
    const msg = message[i];
    if (isCause(msg)) {
      if (cause) {
        ;
        message.splice(i, 1);
      } else {
        message = message.slice(0, i).concat(message.slice(i + 1));
      }
      cause = cause ? causeFromReasons(cause.reasons.concat(msg.reasons)) : msg;
      i--;
    }
  }
  if (cause === undefined) {
    cause = causeEmpty;
  }
  return withFiber(fiber => {
    const logLevel = level ?? fiber.cache.logLevel;
    if (isLogLevelGreaterThan(fiber.cache.minimumLogLevel, logLevel)) {
      return void_;
    }
    const clock = fiber.getRef(ClockRef);
    const loggers = fiber.getRef(CurrentLoggers);
    if (loggers.size > 0) {
      const date = new Date(clock.currentTimeMillisUnsafe());
      for (const logger of loggers) {
        logger.log({
          cause,
          fiber,
          date,
          logLevel,
          message
        });
      }
    }
    return void_;
  });
};
const withColor = (text, ...colors) => {
  let out = "";
  for (let i = 0; i < colors.length; i++) {
    out += `\x1b[${colors[i]}m`;
  }
  return out + text + "\x1b[0m";
};
const withColorNoop = (text, ..._colors) => text;
const colors = {
  bold: "1",
  red: "31",
  green: "32",
  yellow: "33",
  blue: "34",
  cyan: "36",
  white: "37",
  gray: "90",
  black: "30",
  bgBrightRed: "101"
};
const logLevelColors = {
  None: [],
  All: [],
  Trace: [colors.gray],
  Debug: [colors.blue],
  Info: [colors.green],
  Warn: [colors.yellow],
  Error: [colors.red],
  Fatal: [colors.bgBrightRed, colors.black]
};
const logLevelStyle = {
  None: "",
  All: "",
  Trace: "color:gray",
  Debug: "color:blue",
  Info: "color:green",
  Warn: "color:orange",
  Error: "color:red",
  Fatal: "background-color:red;color:white"
};
const defaultDateFormat = date => `${date.getHours().toString().padStart(2, "0")}:${date.getMinutes().toString().padStart(2, "0")}:${date.getSeconds().toString().padStart(2, "0")}.${date.getMilliseconds().toString().padStart(3, "0")}`;
/** @internal */
export const consolePretty = options => {
  // evaluated lazily so the module-level bundle stays free of `process`
  // property accesses, which bundlers must retain as possible side effects
  const process = globalThis.process;
  const hasProcessStdout = typeof process?.stdout === "object" && process.stdout !== null;
  const isDeno = "Deno" in globalThis;
  const mode = options?.mode ?? "auto";
  const isTtyLogger = mode === "auto" ? hasProcessStdout || isDeno : mode === "tty";
  return isTtyLogger ? prettyLoggerTty(options) : prettyLoggerBrowser(options);
};
/** @internal */
export const prettyLoggerTty = options => {
  const formatDate = options?.formatDate ?? defaultDateFormat;
  // evaluated lazily so the module-level bundle stays free of `process`
  // property accesses, which bundlers must retain as possible side effects
  const process = globalThis.process;
  const hasProcessStdout = typeof process?.stdout === "object" && process.stdout !== null;
  const processStdoutIsTTY = hasProcessStdout && process.stdout.isTTY === true;
  const showColors = typeof options?.colors === "boolean" ? options.colors : processStdoutIsTTY;
  const color = showColors ? withColor : withColorNoop;
  const processIsBun = process?.isBun === true;
  return loggerMake(({
    cause,
    date,
    fiber,
    logLevel,
    message: message_
  }) => {
    const console = fiber.getRef(ConsoleRef);
    // oxlint-disable-next-line no-console
    const log = fiber.getRef(LogToStderr) ? console.error : console.log;
    const message = Array.isArray(message_) ? message_.slice() : [message_];
    let firstLine = color(`[${formatDate(date)}]`, colors.white) + ` ${color(logLevel.toUpperCase(), ...logLevelColors[logLevel])}` + ` (#${fiber.id})`;
    const now = date.getTime();
    const spans = fiber.getRef(CurrentLogSpans);
    for (const span of spans) {
      firstLine += " " + formatLogSpan(span, now);
    }
    firstLine += ":";
    let messageIndex = 0;
    if (message.length > 0) {
      const firstMaybeString = structuredMessage(message[0]);
      if (typeof firstMaybeString === "string") {
        firstLine += " " + color(firstMaybeString, colors.bold, colors.cyan);
        messageIndex++;
      }
    }
    log(firstLine);
    // oxlint-disable-next-line no-console
    if (!processIsBun) console.group();
    if (cause.reasons.length > 0) {
      log(causePretty(cause));
    }
    if (messageIndex < message.length) {
      for (; messageIndex < message.length; messageIndex++) {
        log(redact(message[messageIndex]));
      }
    }
    const annotations = fiber.getRef(CurrentLogAnnotations);
    for (const [key, value] of Object.entries(annotations)) {
      log(color(`${key}:`, colors.bold, colors.white), redact(value));
    }
    // oxlint-disable-next-line no-console
    if (!processIsBun) console.groupEnd();
  });
};
/** @internal */
export const prettyLoggerBrowser = options => {
  const showColors = options?.colors !== false;
  const color = showColors ? "%c" : "";
  const formatDate = options?.formatDate ?? defaultDateFormat;
  return loggerMake(({
    cause,
    date,
    fiber,
    logLevel,
    message: message_
  }) => {
    const console = fiber.getRef(ConsoleRef);
    const message = Array.isArray(message_) ? message_.slice() : [message_];
    let firstLine = `${color}[${formatDate(date)}]`;
    const firstParams = [];
    if (showColors) {
      firstParams.push("color:gray");
    }
    firstLine += ` ${color}${logLevel.toUpperCase()}${color} (#${fiber.id})`;
    if (showColors) {
      firstParams.push(logLevelStyle[logLevel], "");
    }
    const now = date.getTime();
    const spans = fiber.getRef(CurrentLogSpans);
    for (const span of spans) {
      firstLine += " " + formatLogSpan(span, now);
    }
    firstLine += ":";
    let messageIndex = 0;
    if (message.length > 0) {
      const firstMaybeString = structuredMessage(message[0]);
      if (typeof firstMaybeString === "string") {
        firstLine += ` ${color}${firstMaybeString}`;
        if (showColors) {
          firstParams.push("color:deepskyblue");
        }
        messageIndex++;
      }
    }
    // oxlint-disable-next-line no-console
    console.groupCollapsed(firstLine, ...firstParams);
    if (cause.reasons.length > 0) {
      // oxlint-disable-next-line no-console
      console.error(causePretty(cause));
    }
    if (messageIndex < message.length) {
      for (; messageIndex < message.length; messageIndex++) {
        // oxlint-disable-next-line no-console
        console.log(redact(message[messageIndex]));
      }
    }
    const annotations = fiber.getRef(CurrentLogAnnotations);
    for (const [key, value] of Object.entries(annotations)) {
      const redacted = redact(value);
      if (showColors) {
        // oxlint-disable-next-line no-console
        console.log(`%c${key}:`, "color:gray", redacted);
      } else {
        // oxlint-disable-next-line no-console
        console.log(`${key}:`, redacted);
      }
    }
    // oxlint-disable-next-line no-console
    console.groupEnd();
  });
};
/** @internal */
export const defaultLogger = /*#__PURE__*/loggerMake(({
  cause,
  date,
  fiber,
  logLevel,
  message
}) => {
  const message_ = Array.isArray(message) ? message.slice() : [message];
  if (cause.reasons.length > 0) {
    message_.push(causePretty(cause));
  }
  const now = date.getTime();
  const spans = fiber.getRef(CurrentLogSpans);
  let spanString = "";
  for (const span of spans) {
    spanString += ` ${formatLogSpan(span, now)}`;
  }
  const annotations = fiber.getRef(CurrentLogAnnotations);
  if (Object.keys(annotations).length > 0) {
    message_.push(annotations);
  }
  const console = fiber.getRef(ConsoleRef);
  // oxlint-disable-next-line no-console
  const log = fiber.getRef(LogToStderr) ? console.error : console.log;
  log(`[${defaultDateFormat(date)}] ${logLevel.toUpperCase()} (#${fiber.id})${spanString}:`, ...message_);
});
/** @internal */
export const tracerLogger = /*#__PURE__*/loggerMake(({
  cause,
  fiber,
  logLevel,
  message
}) => {
  const clock = fiber.getRef(ClockRef);
  const annotations = fiber.getRef(CurrentLogAnnotations);
  const span = fiber.cache.span;
  if (span === undefined || span._tag === "ExternalSpan") return;
  const attributes = {};
  for (const [key, value] of Object.entries(annotations)) {
    InternalRecord.assignProperty(attributes, key, value);
  }
  attributes["effect.fiberId"] = fiber.id;
  attributes["effect.logLevel"] = logLevel.toUpperCase();
  if (cause.reasons.length > 0) {
    attributes["effect.cause"] = causePretty(cause);
  }
  span.event(toStringUnknown(Array.isArray(message) && message.length === 1 ? message[0] : message), clock.currentTimeNanosUnsafe(), attributes);
});
/** @internal */
export function interruptChildrenPatch() {
  fiberMiddleware.interruptChildren ??= fiberInterruptChildren;
}
/** @internal */
const undefined_ = /*#__PURE__*/succeed(undefined);
/** @internal */
export { undefined_ as undefined };
// ----------------------------------------------------------------------------
// ErrorReporter
// ----------------------------------------------------------------------------
/** @internal */
export const withErrorReporting = /*#__PURE__*/dual(args => isEffect(args[0]), (self, options) => onError(self, cause => withFiber(fiber => {
  reportCauseUnsafe(fiber, cause, options?.defectsOnly);
  return void_;
})));
/** @internal */
export const reportCauseUnsafe = (fiber, cause, defectsOnly) => {
  const reporters = fiber.getRef(CurrentErrorReporters);
  if (reporters.size === 0) return;
  if (defectsOnly && !hasDies(cause)) return;
  const opts = {
    cause,
    fiber,
    timestamp: fiber.getRef(ClockRef).currentTimeNanosUnsafe()
  };
  reporters.forEach(reporter => reporter.report(opts));
};
//# sourceMappingURL=effect.js.map